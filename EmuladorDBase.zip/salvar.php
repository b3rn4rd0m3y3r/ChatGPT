<?php
$data = json_decode(file_get_contents("php://input"), true);
$nome = basename($data["nome"]);
$dados = $data["dados"];

if (!$nome || !$dados) {
  http_response_code(400);
  echo "Dados inv�lidos";
  exit;
}

$arquivo = "./tabelas/{$nome}.json";
file_put_contents($arquivo, json_encode($dados, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
echo "Tabela '{$nome}' salva com sucesso!";
?>
