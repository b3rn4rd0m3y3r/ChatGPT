class JSONDB {
  constructor() {
    this.schema = [];
    this.dados = [];
    this.nomeTabela = "";
  }

  async carregar(nome) {
    this.nomeTabela = nome;
    const res = await fetch(`tabelas/${nome}.json`);
    const json = await res.json();
    this.schema = json.schema;
    this.dados = json.dados;
  }

  inserir(registro) {
    this.dados.push(registro);
  }

  deletar(indice) {
    this.dados.splice(indice, 1);
  }

  alterar(indice, registro) {
    this.dados[indice] = registro;
  }

  exportar() {
    return {
      schema: this.schema,
      dados: this.dados
    };
  }
}
