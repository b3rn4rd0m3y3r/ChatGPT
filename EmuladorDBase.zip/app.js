const db = new JSONDB();
// 1 - Acr�scimo para edi��o (ED)
let indiceEditando = null;
// Acr�scimo para considerar a unicidade da chave prim�ria
const chavePrimaria = "codigo";
// 1 - Acr�scimo para pesquisas
let dadosFiltrados = []; // Exibe apenas registros filtrados
let ordemAtual = { campo: null, asc: true };

async function carregarTabela() {
  const nome = document.getElementById("tabelaSelect").value;

  if (!nome) {
    limparInterface(); // Ao escolher [Nenhuma]
    return;
  }

  await db.carregar(nome);
  dadosFiltrados = [...db.dados];

  document.getElementById("painelControles").style.display = "block";
  document.getElementById("painelFormulario").style.display = "block";

  limparCamposDeFiltro();
  renderTabela();
  renderFormulario();
  renderControlesFiltro();
}


// 2 - Altera��o para pesquisa (PSQ)
async function carregarTabelaOLD1() {
  const nome = document.getElementById("tabelaSelect").value;
  await db.carregar(nome);
  renderTabela();
  renderFormulario();
}

async function carregarTabelaOLD2() {
  const nome = document.getElementById("tabelaSelect").value;

  // Evita cache com um timestamp no final da URL
  const url = `tabelas/${nome}.json?t=${Date.now()}`;
  const res = await fetch(url, { cache: "no-store" });

  const json = await res.json();
  db.nomeTabela = nome;
  db.schema = json.schema;
  db.dados = json.dados;

  renderTabela();
  renderFormulario();
}

async function carregarTabelaOLD3() {
  const nome = document.getElementById("tabelaSelect").value;
  await db.carregar(nome);
  dadosFiltrados = [...db.dados];
  renderTabela();
  renderFormulario();
  renderControlesFiltro();
}

async function carregarTabelaOLD4() {
  const nome = document.getElementById("tabelaSelect").value;
  await db.carregar(nome);
  dadosFiltrados = [...db.dados];

  // Exibe os elementos de controle
  document.getElementById("painelControles").style.display = "block";

  renderTabela();
  renderFormulario();
  renderControlesFiltro();
}

function renderTabelaOLD1() {
  const tabela = document.getElementById("tabelaDados");
  tabela.innerHTML = "";

  const thead = document.createElement("tr");
  db.schema.forEach(campo => {
    const th = document.createElement("th");
    th.textContent = campo;
    thead.appendChild(th);
  });
  thead.appendChild(document.createElement("th")); // A��es
  tabela.appendChild(thead);

  db.dados.forEach((registro, i) => {
    const tr = document.createElement("tr");
    db.schema.forEach(campo => {
      const td = document.createElement("td");
      td.textContent = registro[campo];
      tr.appendChild(td);
    });

    const tdAcoes = document.createElement("td");
    // Veio com "???" e tivemos que digitar DELETAR
    tdAcoes.innerHTML = `<button onclick="db.deletar(${i}); renderTabela()">DELETAR</button>`;
    tr.appendChild(tdAcoes);
    tabela.appendChild(tr);
  });
}

// 2 - Altera��o para edi��o (ED)
function renderTabelaOLD2() {
  const tabela = document.getElementById("tabelaDados");
  tabela.innerHTML = "";

  const thead = document.createElement("tr");
  db.schema.forEach(campo => {
    const th = document.createElement("th");
    th.textContent = campo;
    thead.appendChild(th);
  });
  thead.appendChild(document.createElement("th")); // A��es
  tabela.appendChild(thead);

  db.dados.forEach((registro, i) => {
    const tr = document.createElement("tr");
    db.schema.forEach(campo => {
      const td = document.createElement("td");
      td.textContent = registro[campo];
      tr.appendChild(td);
    });

    const tdAcoes = document.createElement("td");
    tdAcoes.innerHTML = `
      <button onclick="editarRegistro(${i})">EDITAR</button>
      <button onclick="db.deletar(${i}); renderTabela()">DELETAR</button>
    `;
    tr.appendChild(tdAcoes);
    tabela.appendChild(tr);
  });
}

//5 - Altera��o para pesquisa (PSQ)
function renderTabelaOLD3() {
  const tabela = document.getElementById("tabelaDados");
  tabela.innerHTML = "";

  const thead = document.createElement("tr");
  db.schema.forEach(campo => {
    const th = document.createElement("th");
    th.textContent = campo + (ordemAtual.campo === campo ? (ordemAtual.asc ? " ?" : " ?") : "");
    th.style.cursor = "pointer";
    th.onclick = () => ordenarPor(campo);
    thead.appendChild(th);
  });
  thead.appendChild(document.createElement("th")); // A��es
  tabela.appendChild(thead);

  dadosFiltrados.forEach((registro, i) => {
    const tr = document.createElement("tr");
    db.schema.forEach(campo => {
      const td = document.createElement("td");
      td.textContent = registro[campo];
      tr.appendChild(td);
    });

    const tdAcoes = document.createElement("td");
    tdAcoes.innerHTML = `
      <button onclick="editarRegistro(${i})">EDITAR</button>
      <button onclick="db.deletar(${i}); filtrarRegistros()">DELETAR</button>
    `;
    tr.appendChild(tdAcoes);
    tabela.appendChild(tr);
  });
}

// Corre��o do problema posicional da EDI��O ap�s uma ordena��o
function renderTabela() {
  const tabela = document.getElementById("tabelaDados");
  tabela.innerHTML = "";
  // Necess�rio devido � introdu��o da ordena��o da tabela
  const chavePrimaria = "codigo"; // Assumimos que "codigo" � o identificador �nico
  
  const thead = document.createElement("tr");
  db.schema.forEach(campo => {
    const th = document.createElement("th");
    th.textContent = campo + (ordemAtual.campo === campo ? (ordemAtual.asc ? " ?" : " ?") : "");
    th.style.cursor = "pointer";
    th.onclick = () => ordenarPor(campo);
    thead.appendChild(th);
  });
  thead.appendChild(document.createElement("th")); // A��es
  tabela.appendChild(thead);

	dadosFiltrados.forEach((registro) => {
	  const tr = document.createElement("tr");
	  db.schema.forEach(campo => {
	    const td = document.createElement("td");
	    td.textContent = registro[campo];
	    tr.appendChild(td);
	  });

	  const tdAcoes = document.createElement("td");
	  tdAcoes.innerHTML = `
	    <button onclick="editarRegistroPorCodigo('${registro[chavePrimaria]}')">EDITAR</button>
	    <button onclick="deletarRegistroPorCodigo('${registro[chavePrimaria]}')">DELETAR</button>
	  `;
	  tr.appendChild(tdAcoes);
	  tabela.appendChild(tr);
	});
}
// Localizar registro pelo codigo original
function encontrarIndicePorCodigo(codigo) {
  return db.dados.findIndex(r => r.codigo == codigo);
}
// Edita registro pelo c�digo e n�o pela posi��o
function editarRegistroPorCodigo(codigo) {
  const i = encontrarIndicePorCodigo(codigo);
  if (i < 0) return;

  indiceEditando = i;
  const registro = db.dados[i];
  db.schema.forEach(campo => {
    document.getElementById(`campo_${campo}`).value = registro[campo];
  });

  document.querySelector('button[type="submit"]').style.display = "none";

  if (!document.getElementById("btnSalvarAlteracao")) {
    const btnSalvar = document.createElement("button");
    btnSalvar.id = "btnSalvarAlteracao";
    btnSalvar.textContent = "Salvar altera��o";
    btnSalvar.onclick = salvarAlteracao;
    document.getElementById("registroForm").appendChild(btnSalvar);
  }
}
// Deletar registro pelo c�digo e n�o pela posi��o
function deletarRegistroPorCodigo(codigo) {
  const i = encontrarIndicePorCodigo(codigo);
  if (i < 0) return;

  db.deletar(i);
  dadosFiltrados = [...db.dados];
  renderTabela();
}
// 3 - Acr�scimo para Edi��o (ED)
function editarRegistro(indice) {
  indiceEditando = indice;
  const registro = db.dados[indice];
  db.schema.forEach(campo => {
    document.getElementById(`campo_${campo}`).value = registro[campo];
  });

  document.querySelector('button[onclick="inserirRegistro()"]').style.display = "none";
  if (!document.getElementById("btnSalvarAlteracao")) {
    const btnSalvar = document.createElement("button");
    btnSalvar.id = "btnSalvarAlteracao";
    btnSalvar.textContent = "Salvar altera��o";
    btnSalvar.onclick = salvarAlteracao;
    document.getElementById("registroForm").appendChild(btnSalvar);
  }
}

// 4 - Acr�scimo para Edi��o (ED)
function salvarAlteracao() {
  const novoRegistro = {};
  db.schema.forEach(campo => {
    novoRegistro[campo] = document.getElementById(`campo_${campo}`).value;
  });

  db.alterar(indiceEditando, novoRegistro);
  indiceEditando = null;
  renderTabela();
  renderFormulario();
}

function renderFormulario() {
  const form = document.getElementById("registroForm");
  form.innerHTML = "";

  db.schema.forEach(campo => {
    const input = document.createElement("input");
    input.placeholder = campo;
    input.id = `campo_${campo}`;
    form.appendChild(input);
  });

  const btnInserir = document.createElement("button");
  btnInserir.textContent = "Inserir";
  btnInserir.type = "submit";
  form.appendChild(btnInserir);

  const btnSalvar = document.createElement("button");
  btnSalvar.textContent = "Salvar no servidor";
  btnSalvar.type = "button";
  btnSalvar.onclick = salvarTabela;
  form.appendChild(btnSalvar);
}

function renderFormularioOLD1() {
  const form = document.getElementById("registroForm");
  form.innerHTML = "";
  db.schema.forEach(campo => {
    const input = document.createElement("input");
    input.placeholder = campo;
    input.id = `campo_${campo}`;
    form.appendChild(input);
  });
}

// 5 - Altera��o para Edi��o (ED)
function renderFormularioOLD2() {
  const form = document.getElementById("registroForm");
  form.innerHTML = "";
  db.schema.forEach(campo => {
    const input = document.createElement("input");
    input.placeholder = campo;
    input.id = `campo_${campo}`;
    form.appendChild(input);
  });

  const btnInserir = document.createElement("button");
  btnInserir.textContent = "Inserir";
  btnInserir.setAttribute("onclick", "inserirRegistro()");
  form.appendChild(btnInserir);
}

// Manuten��o necess�ria para validar a unicidade
// da chave prim�ria
function inserirRegistro() {
  const registro = {};
  db.schema.forEach(campo => {
    registro[campo] = document.getElementById(`campo_${campo}`).value.trim();
  });

  // Verifica unicidade do campo chave
  const existe = db.dados.some(r => r[chavePrimaria] === registro[chavePrimaria]);
  if (existe) {
    alert(`J� existe um registro com ${chavePrimaria} = ${registro[chavePrimaria]}.`);
    return;
  }

  db.inserir(registro);
  dadosFiltrados = [...db.dados];

  // Limpa formul�rio
  db.schema.forEach(campo => {
    document.getElementById(`campo_${campo}`).value = "";
  });

  renderTabela();
}

// Manuten��o necess�ria para n�o confundir o usu�rio
// ap�s uma inclus�o, recarregando a tabela
function inserirRegistroOLD2() {
  const registro = {};
  db.schema.forEach(campo => {
    registro[campo] = document.getElementById(`campo_${campo}`).value;
  });

  db.inserir(registro);

  // Atualiza o conjunto filtrado
  dadosFiltrados = [...db.dados];

  // Limpa os campos do formul�rio
  db.schema.forEach(campo => {
    document.getElementById(`campo_${campo}`).value = "";
  });

  // Reexibe a tabela com o novo registro
  renderTabela();
}

function inserirRegistroOLD1() {
  const registro = {};
  db.schema.forEach(campo => {
    registro[campo] = document.getElementById(`campo_${campo}`).value;
  });
  db.inserir(registro);
  renderTabela();
}

// Com algumas implementa��es na interface e renderiza��es aqui no app.js,
// O antigo erro de carregamento ap�s inclus�es voltou a aparecer, dai ser
// necess�ria uma altera��o no salvarTabela

async function salvarTabela() {
  const nome = db.nomeTabela;
  const dados = db.exportar();

  const res = await fetch(`salvar.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nome, dados })
  });

  const texto = await res.text();
  alert(texto);

  // Recarrega os dados salvos diretamente do arquivo .json
  await db.carregar(nome);
  dadosFiltrados = [...db.dados];
  renderTabela();
  renderFormulario();
  renderControlesFiltro();
}

async function salvarTabelaOLD1() {
  const nome = db.nomeTabela;
  const dados = db.exportar();
  const res = await fetch(`salvar.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nome, dados })
  });
  const texto = await res.text();
  alert(texto);
}

// 3 - Acr�scimo para as pesquisas (PSQ)
function renderControlesFiltro() {
  const campoFiltro = document.getElementById("campoFiltro");
  campoFiltro.innerHTML = `<option value="">[Todos os campos]</option>`;
  db.schema.forEach(campo => {
    const opt = document.createElement("option");
    opt.value = campo;
    opt.textContent = campo;
    campoFiltro.appendChild(opt);
  });
}

// 4 - Acr�scimo para as pesquisas (PSQ)
function filtrarRegistros() {
  const busca = document.getElementById("buscaGlobal").value.toLowerCase();
  const campo = document.getElementById("campoFiltro").value;
  const valor = document.getElementById("valorFiltro").value.toLowerCase();

  dadosFiltrados = db.dados.filter(reg => {
    const textoGlobal = Object.values(reg).join(" ").toLowerCase();
    const matchBusca = !busca || textoGlobal.includes(busca);
    const matchCampo = !campo || (reg[campo] + "").toLowerCase().includes(valor);
    return matchBusca && matchCampo;
  });

  renderTabela();
}

// 6 - Acr�scimo para pesquisas (PSQ
function ordenarPor(campo) {
  const asc = (ordemAtual.campo === campo) ? !ordemAtual.asc : true;
  ordemAtual = { campo, asc };

  dadosFiltrados.sort((a, b) => {
    const valA = a[campo]?.toString().toLowerCase() || "";
    const valB = b[campo]?.toString().toLowerCase() || "";
    if (valA < valB) return asc ? -1 : 1;
    if (valA > valB) return asc ? 1 : -1;
    return 0;
  });

  renderTabela();
}

function limparInterface() {
  db.nomeTabela = "";
  db.schema = [];
  db.dados = [];
  dadosFiltrados = [];
  indiceEditando = null;

  document.getElementById("painelControles").style.display = "none";
  document.getElementById("painelFormulario").style.display = "none";
  document.getElementById("tabelaDados").innerHTML = "";
  document.getElementById("registroForm").innerHTML = "";
}

function limparCamposDeFiltro() {
  document.getElementById("buscaGlobal").value = "";
  document.getElementById("campoFiltro").value = "";
  document.getElementById("valorFiltro").value = "";
}