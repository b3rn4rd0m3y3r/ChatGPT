# WebAccess — Sessão 07 (Editor SQL)

## O que esta versão acrescenta
Esta versão dá continuidade à Sessão 06 e implementa o editor SQL utilizando o SQL.js 1.14.1 já incorporado localmente. Não há dependência de CDN ou conexão com a internet para executar o aplicativo.

O editor permite executar uma instrução SQL por vez:
- `SELECT` — consulta e apresenta os resultados em uma grade.
- `INSERT` — insere registros.
- `UPDATE` — atualiza registros.
- `DELETE` — exclui registros.

O atalho **Ctrl+Enter** executa o comando. A interface informa erros do SQLite e, nos comandos de alteração, mostra a quantidade de registros afetados.

## Persistência das alterações
Quando um comando `INSERT`, `UPDATE` ou `DELETE` é executado:
1. O comando é executado pelo SQLite.
2. Os registros das tabelas são sincronizados de volta para a estrutura de dados do WebAccess.
3. O snapshot JSON é salvo no object store original `bancos`, chave `banco_atual`.
4. A cópia binária SQLite é atualizada no object store `sqlite_bancos`, chave `banco_sqlite`.

Assim, as alterações SQL permanecem disponíveis ao reabrir o WebAccess e continuam incluídas no backup JSON.

## Limites desta etapa
- Apenas `SELECT`, `INSERT`, `UPDATE` e `DELETE` são aceitos nesta etapa.
- Execute uma instrução por vez.
- Comandos de estrutura como `CREATE TABLE`, `ALTER TABLE` e `DROP TABLE` serão tratados na etapa de gerenciamento da estrutura.
- Faça um backup JSON antes de alterações importantes, especialmente antes de usar `UPDATE` ou `DELETE` sem uma cláusula `WHERE`.
- A execução SQL respeita as chaves estrangeiras configuradas no banco SQLite.

## Atualização
1. Faça um backup JSON pelo WebAccess atual.
2. Feche as outras abas do WebAccess.
3. Extraia esta versão em uma pasta nova para teste ou sobre a pasta do aplicativo, sem apagar a pasta de dados do navegador.
4. Abra `index.html` no mesmo navegador e perfil usados anteriormente.
5. Aguarde os indicadores de armazenamento e SQLite ficarem prontos.
6. Abra **Consultas SQL** e teste primeiro um `SELECT`.

**Importante:** não limpe os dados do site, não exclua o IndexedDB e não remova a versão anterior até confirmar que a nova versão está funcionando.

## Arquivos principais
- `index.html`: interface do aplicativo e editor SQL.
- `css/style.css`: estilos da interface e do editor.
- `js/app.js`: eventos do editor e sincronização com o modelo WebAccess.
- `js/sqlite.js`: execução SQL e integração com SQL.js.
- `js/persistencia.js`: armazenamento JSON e cópia SQLite no IndexedDB.
- `lib/sql-wasm-inline.js`: SQL.js 1.14.1 com WebAssembly incorporado.
