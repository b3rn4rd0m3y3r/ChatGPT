// WebAccess — motor SQLite local (SQL.js)
"use strict";

window.WebAccessSQLite = (() => {
  let SQL = null;
  let database = null;
  let ready = false;
  let syncQueue = Promise.resolve();

  function setStatus(message, state = "") {
    const element = document.querySelector("#sqliteStatus");
    if (!element) return;
    element.textContent = message;
    element.className = `storage-status ${state}`.trim();
  }

  function quoteIdentifier(identifier) {
    return `"${String(identifier).replace(/"/g, '""')}"`;
  }

  function sqliteType(type) {
    const normalized = String(type || "TEXT").toUpperCase();
    if (normalized === "INTEGER" || normalized === "BOOLEAN") return "INTEGER";
    if (normalized === "REAL") return "REAL";
    if (normalized === "NUMERIC") return "NUMERIC";
    return "TEXT";
  }

  function normalizeValue(value, field) {
    if (value === undefined) return null;
    if (typeof value === "boolean") return value ? 1 : 0;
    if (value instanceof Date) return value.toISOString();
    if (value !== null && typeof value === "object" && !(value instanceof Uint8Array)) {
      return JSON.stringify(value);
    }
    return value;
  }

  function createDatabase(snapshot) {
    if (!snapshot || !Array.isArray(snapshot.tables) || !Array.isArray(snapshot.relationships)) {
      throw new Error("Não foi possível montar o SQLite: estrutura do banco inválida.");
    }

    const nextDb = new SQL.Database();
    try {
      nextDb.run("PRAGMA foreign_keys = ON;");

      const tableById = new Map(snapshot.tables.map(table => [table.id, table]));
      for (const table of snapshot.tables) {
        if (!table.fields || table.fields.length === 0) {
          throw new Error(`A tabela "${table.name}" não possui campos.`);
        }

        const definitions = table.fields.map(field => {
          let definition = `${quoteIdentifier(field.name)} ${sqliteType(field.type)}`;
          if (field.primaryKey) definition += " PRIMARY KEY";
          return definition;
        });

        const relations = snapshot.relationships.filter(rel => rel.childTableId === table.id);
        for (const rel of relations) {
          const parent = tableById.get(rel.parentTableId);
          if (!parent) throw new Error(`Tabela principal não encontrada no relacionamento da tabela "${table.name}".`);
          definitions.push(
            `FOREIGN KEY (${quoteIdentifier(rel.childFieldName)}) REFERENCES ${quoteIdentifier(parent.name)} (${quoteIdentifier(rel.parentFieldName)})`
          );
        }

        nextDb.run(`CREATE TABLE ${quoteIdentifier(table.name)} (${definitions.join(", ")});`);
      }

      // Adia a validação das FKs até o COMMIT: assim, a ordem visual das
      // tabelas no WebAccess não interfere na conversão dos registros.
      nextDb.run("PRAGMA defer_foreign_keys = ON; BEGIN;");
      for (const table of snapshot.tables) {
        if (!table.records || table.records.length === 0) continue;
        const columns = table.fields.map(field => quoteIdentifier(field.name));
        const placeholders = table.fields.map(() => "?").join(", ");
        const statement = nextDb.prepare(
          `INSERT INTO ${quoteIdentifier(table.name)} (${columns.join(", ")}) VALUES (${placeholders});`
        );
        try {
          for (const record of table.records) {
            const values = table.fields.map(field => normalizeValue(record.values?.[field.name], field));
            statement.run(values);
          }
        } finally {
          statement.free();
        }
      }
      nextDb.run("COMMIT;");

      return nextDb;
    } catch (error) {
      try { nextDb.run("ROLLBACK;"); } catch (_) {}
      nextDb.close();
      throw error;
    }
  }

  async function performSync(snapshot) {
    let nextDb = null;
    try {
      nextDb = createDatabase(snapshot);
      const bytes = nextDb.export();
      await WebAccessPersistence.saveSqliteBytes(bytes);
      const previousDb = database;
      database = nextDb;
      nextDb = null;
      if (previousDb) previousDb.close();
      setStatus("SQLite sincronizado", "saved");
      return true;
    } catch (error) {
      setStatus("Erro no SQLite", "error");
      throw error;
    } finally {
      if (nextDb) nextDb.close();
    }
  }

  function syncSnapshot(snapshot) {
    if (!ready || !SQL) return Promise.resolve(false);
    // Serializa as sincronizações para que uma gravação mais recente não seja
    // ignorada enquanto a cópia SQLite anterior ainda está sendo persistida.
    const operation = syncQueue.then(() => performSync(snapshot));
    syncQueue = operation.catch(() => false);
    return operation;
  }

  async function initialize(snapshotProvider) {
    setStatus("Carregando SQL.js...", "saving");
    try {
      if (typeof window.initSqlJs !== "function") {
        throw new Error("O arquivo sql-wasm-inline.js não foi carregado.");
      }
      SQL = await window.initSqlJs();
      ready = true;
      await syncSnapshot(snapshotProvider());
      console.info("WebAccess: SQL.js inicializado; SQLite em memória e cópia binária no IndexedDB.");
      return true;
    } catch (error) {
      ready = false;
      setStatus("SQLite indisponível", "error");
      throw error;
    }
  }


  function hasMultipleStatements(sql) {
    let quote = null, escaped = false;
    for (let i = 0; i < sql.length; i++) {
      const ch = sql[i];
      if (quote) {
        if (ch === quote) {
          if (sql[i + 1] === quote) { i++; continue; }
          quote = null;
        } else if (ch === "\\" && quote !== "'") escaped = !escaped;
        continue;
      }
      if (ch === "'" || ch === '"' || ch === '`' || ch === '[') { quote = ch === '[' ? ']' : ch; continue; }
      if (ch === ';' && sql.slice(i + 1).trim()) return true;
    }
    return false;
  }

  function snapshotFromDatabase(snapshot) {
    const copy = JSON.parse(JSON.stringify(snapshot));
    for (const table of copy.tables) {
      const oldRecords = table.records || [];
      const columns = table.fields.map(field => quoteIdentifier(field.name)).join(', ');
      const result = database.exec(`SELECT ${columns} FROM ${quoteIdentifier(table.name)};`);
      const rows = result.length ? result[0].values : [];
      const pk = table.fields.find(field => field.primaryKey);
      const used = new Set();
      table.records = rows.map((row, index) => {
        const values = {};
        table.fields.forEach((field, i) => { values[field.name] = row[i] === undefined ? null : row[i]; });
        let previous = null;
        if (pk) previous = oldRecords.find(record => !used.has(record.id) && String(record.values?.[pk.name]) === String(values[pk.name]));
        if (!previous) previous = oldRecords.find(record => !used.has(record.id) && table.fields.every(field => JSON.stringify(record.values?.[field.name] ?? null) === JSON.stringify(values[field.name] ?? null)));
        const id = previous ? previous.id : `sql_${Date.now()}_${index}_${Math.random().toString(36).slice(2, 8)}`;
        if (previous) used.add(previous.id);
        return { id, values };
      });
    }
    return copy;
  }

  async function execute(sql, snapshotProvider, snapshotApplier, saveCallback) {
    if (!ready || !database) throw new Error("O mecanismo SQLite ainda não está pronto.");
    const statement = String(sql || '').trim();
    if (!statement) throw new Error('Digite uma instrução SQL antes de executar.');
    if (hasMultipleStatements(statement)) throw new Error('Execute apenas uma instrução SQL por vez.');
    const normalized = statement.replace(/^(?:\s|--[^\n]*\n|\/\*[\s\S]*?\*\/)+/g, '').trim();
    const command = (normalized.match(/^([a-z]+)/i) || [])[1]?.toUpperCase();
    if (!['SELECT', 'INSERT', 'UPDATE', 'DELETE'].includes(command)) {
      throw new Error('Nesta etapa são permitidos apenas SELECT, INSERT, UPDATE e DELETE.');
    }
    if (command === 'SELECT') return { command, results: database.exec(statement), changed: 0 };
    database.run(statement);
    const changed = database.getRowsModified();
    const updatedSnapshot = snapshotFromDatabase(snapshotProvider());
    snapshotApplier(updatedSnapshot);
    await saveCallback();
    setStatus('SQLite sincronizado', 'saved');
    return { command, results: [], changed };
  }

  function exec(sql, params) {
    if (!ready || !database) throw new Error("O mecanismo SQLite ainda não está pronto.");
    return database.exec(sql, params);
  }

  function exportBytes() {
    if (!ready || !database) throw new Error("O mecanismo SQLite ainda não está pronto.");
    return database.export();
  }

  function getDatabase() {
    if (!ready || !database) throw new Error("O mecanismo SQLite ainda não está pronto.");
    return database;
  }

  return {
    initialize,
    syncSnapshot,
    exec,
    execute,
    exportBytes,
    getDatabase,
    isReady: () => ready
  };
})();
