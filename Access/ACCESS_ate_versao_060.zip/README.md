# WebAccess — Sessão 06 (SQL.js)

## O que esta versão acrescenta
Esta versão incorpora o SQL.js 1.14.1 localmente. O mecanismo SQLite é inicializado no navegador, sem CDN e sem buscar arquivos externos.

Na inicialização, o modelo atual do WebAccess (tabelas, campos, chaves primárias, relacionamentos e registros) é convertido para um banco SQLite real em memória. Uma cópia binária exportada pelo SQL.js é gravada no IndexedDB.

## Preservação dos dados
- O banco IndexedDB continua sendo `WebAccessStorage`.
- O object store original `bancos` e a chave `banco_atual` são mantidos.
- A cópia SQLite é armazenada separadamente em `sqlite_bancos`, chave `banco_sqlite`.
- O backup JSON da Sessão 05.5 continua disponível.
- A atualização do IndexedDB acrescenta um object store; não apaga nem recria o armazenamento original.

## Como executar
1. Extraia o ZIP em uma pasta nova.
2. Abra `index.html` no mesmo navegador e perfil em que o WebAccess já era utilizado.
3. Aguarde os indicadores “Salvo neste navegador” e “SQLite sincronizado”.
4. Faça uma alteração simples (por exemplo, crie uma tabela) e aguarde o salvamento automático.

## Limites desta etapa
A interface de edição e execução de comandos SQL será construída na Etapa 3. Nesta etapa, o SQL.js já inicializa o mecanismo SQLite e mantém a cópia binária sincronizada com o modelo atual do WebAccess.

## Arquivos principais
- `index.html`: interface e carregamento dos scripts locais.
- `js/app.js`: aplicação.
- `js/persistencia.js`: persistência JSON e IndexedDB.
- `js/sqlite.js`: integração e conversão do modelo WebAccess para SQLite.
- `lib/sql-wasm-inline.js`: distribuição SQL.js 1.14.1 com WebAssembly incorporado.
