
// We are modularizing this manually because the current modularize setting in Emscripten has some issues:
// https://github.com/kripken/emscripten/issues/5820
// In addition, When you use emcc's modularization, it still expects to export a global object called `Module`,
// which is able to be used/called before the WASM is loaded.
// The modularization below exports a promise that loads and resolves to the actual sql.js module.
// That way, this module can't be used before the WASM is finished loading.

// We are going to define a function that a user will call to start loading initializing our Sql.js library
// However, that function might be called multiple times, and on subsequent calls, we don't actually want it to instantiate a new instance of the Module
// Instead, we want to return the previously loaded module

// TODO: Make this not declare a global if used in the browser
var initSqlJsPromise = undefined;

var initSqlJs = function (moduleConfig) {

    if (initSqlJsPromise){
      return initSqlJsPromise;
    }
    // If we're here, we've never called this function before
    initSqlJsPromise = new Promise(function (resolveModule, reject) {

        // We are modularizing this manually because the current modularize setting in Emscripten has some issues:
        // https://github.com/kripken/emscripten/issues/5820

        // The way to affect the loading of emcc compiled modules is to create a variable called `Module` and add
        // properties to it, like `preRun`, `postRun`, etc
        // We are using that to get notified when the WASM has finished loading.
        // Only then will we return our promise

        // If they passed in a moduleConfig object, use that
        // Otherwise, initialize Module to the empty object
        var Module = typeof moduleConfig !== 'undefined' ? moduleConfig : {};

        // EMCC only allows for a single onAbort function (not an array of functions)
        // So if the user defined their own onAbort function, we remember it and call it
        var originalOnAbortFunction = Module['onAbort'];
        Module['onAbort'] = function (errorThatCausedAbort) {
            reject(new Error(errorThatCausedAbort));
            if (originalOnAbortFunction){
              originalOnAbortFunction(errorThatCausedAbort);
            }
        };

        Module['postRun'] = Module['postRun'] || [];
        Module['postRun'].push(function () {
            // When Emscripted calls postRun, this promise resolves with the built Module
            resolveModule(Module);
        });

        // There is a section of code in the emcc-generated code below that looks like this:
        // (Note that this is lowercase `module`)
        // if (typeof module !== 'undefined') {
        //     module['exports'] = Module;
        // }
        // When that runs, it's going to overwrite our own modularization export efforts in shell-post.js!
        // The only way to tell emcc not to emit it is to pass the MODULARIZE=1 or MODULARIZE_INSTANCE=1 flags,
        // but that carries with it additional unnecessary baggage/bugs we don't want either.
        // So, we have three options:
        // 1) We undefine `module`
        // 2) We remember what `module['exports']` was at the beginning of this function and we restore it later
        // 3) We write a script to remove those lines of code as part of the Make process.
        //
        // Since those are the only lines of code that care about module, we will undefine it. It's the most straightforward
        // of the options, and has the side effect of reducing emcc's efforts to modify the module if its output were to change in the future.
        // That's a nice side effect since we're handling the modularization efforts ourselves
        module = undefined;

        // The emcc-generated code and shell-post.js code goes below,
        // meaning that all of it runs inside of this promise. If anything throws an exception, our promise will abort
var k;k||=typeof Module != 'undefined' ? Module : {};var aa=!!globalThis.window,ca=!!globalThis.WorkerGlobalScope,da=globalThis.process?.versions?.node&&globalThis.process?.type!="renderer";
k.onRuntimeInitialized=function(){function a(f,h){tb(f,h instanceof Error?h.message:String(h),-1)}function b(f,h){switch(typeof h){case "boolean":kc(f,h?1:0);break;case "number":lc(f,h);break;case "string":mc(f,h,m(h),-1);break;case "object":if(h===null)ub(f);else if(h.length!=null){var p=ea(h.length);u.set(h,p);nc(f,p,h.length,-1);y(p)}else tb(f,"Wrong API use : tried to return a value of an unknown type ("+h+").",-1);break;default:ub(f)}}function d(f,h){for(var p=[],q=0;q<f;q+=1){var t=A(h+4*q,
"i32"),w=oc(t);if(w===1||w===2)t=pc(t);else if(w===3)w=vb(t),t=qc(t),t=B(t,w,!0);else if(w===4){w=t;t=vb(w);w=rc(w);for(var x=new Uint8Array(t),G=0;G<t;G+=1)x[G]=u[w+G];t=x}else t=null;p.push(t)}return p}function c(f,h){this.Ua=f;this.db=h;this.Sa=1;this.qb=[]}function e(f,h){this.db=h;this.jb=fa(f);if(this.jb===null)throw Error("Unable to allocate memory for the SQL string");this.ob=this.jb;this.ab=this.wb=null}function g(f){this.filename="dbfile_"+(4294967295*Math.random()>>>0);f!=null&&ja(this.filename,
f);this.handleError(z(this.filename,v));this.db=A(v,"i32");sc(this.db);this.pb={};this.Xa=new Map}function n(f,h){return f.replace(/[A-Z]/g,function(p){return p.toLowerCase()})+":"+h}function r(f){f.forEach(ka)}var v=la(4),l=k.cwrap,z=l("sqlite3_open","number",["string","number"]),F=l("sqlite3_close_v2","number",["number"]),ba=l("sqlite3_backup_init","number",["number","string","number","string"]),za=l("sqlite3_backup_step","number",["number","number"]),ma=l("sqlite3_backup_finish","number",["number"]),
Aa=l("sqlite3_exec","number",["number","number","number","number","number"]),ha=l("sqlite3_changes","number",["number"]),Ba=l("sqlite3_sql","string",["number"]),N=l("sqlite3_normalized_sql","string",["number"]),Ua=l("sqlite3_prepare_v2","number",["number","number","number","number","number"]),tc=l("sqlite3_bind_text","number",["number","number","number","number","number"]),xb=l("sqlite3_bind_blob","number",["number","number","number","number","number"]),uc=l("sqlite3_bind_double","number",["number",
"number","number"]),vc=l("sqlite3_bind_int","number",["number","number","number"]),wc=l("sqlite3_bind_parameter_index","number",["number","string"]),xc=l("sqlite3_step","number",["number"]),ia=l("sqlite3_errmsg","string",["number"]),yc=l("sqlite3_column_count","number",["number"]),zc=l("sqlite3_data_count","number",["number"]),Ac=l("sqlite3_column_double","number",["number","number"]),Bc=l("sqlite3_column_text","number",["number","number"]),Cc=l("sqlite3_column_blob","number",["number","number"]),
yb=l("sqlite3_column_bytes","number",["number","number"]),Dc=l("sqlite3_column_type","number",["number","number"]),Ec=l("sqlite3_column_name","string",["number","number"]),Fc=l("sqlite3_reset","number",["number"]),Gc=l("sqlite3_clear_bindings","number",["number"]),Hc=l("sqlite3_finalize","number",["number"]),zb=l("sqlite3_create_function_v2","number","number string number number number number number number number".split(" ")),oc=l("sqlite3_value_type","number",["number"]),vb=l("sqlite3_value_bytes",
"number",["number"]),qc=l("sqlite3_value_text","number",["number"]),rc=l("sqlite3_value_blob","number",["number"]),pc=l("sqlite3_value_double","number",["number"]),lc=l("sqlite3_result_double","",["number","number"]),ub=l("sqlite3_result_null","",["number"]),mc=l("sqlite3_result_text","",["number","string","number","number"]),nc=l("sqlite3_result_blob","",["number","number","number","number"]),kc=l("sqlite3_result_int","",["number","number"]),tb=l("sqlite3_result_error","",["number","string","number"]),
Ab=l("sqlite3_aggregate_context","number",["number","number"]),sc=l("RegisterExtensionFunctions","number",["number"]),Bb=l("sqlite3_update_hook","number",["number","number","number"]);c.prototype.bind=function(f){if(!this.Ua)throw"Statement closed";this.reset();return Array.isArray(f)?this.Nb(f):f!=null&&typeof f==="object"?this.Ob(f):!0};c.prototype.step=function(){if(!this.Ua)throw"Statement closed";this.Sa=1;var f=xc(this.Ua);switch(f){case 100:return!0;case 101:return!1;default:throw this.db.handleError(f);
}};c.prototype.Gb=function(f){f==null&&(f=this.Sa,this.Sa+=1);return Ac(this.Ua,f)};c.prototype.Wb=function(f){f==null&&(f=this.Sa,this.Sa+=1);if(typeof BigInt!=="function")throw Error("BigInt is not supported");return BigInt(this.Hb(f))};c.prototype.Hb=function(f){f==null&&(f=this.Sa,this.Sa+=1);var h=Bc(this.Ua,f);f=yb(this.Ua,f);return B(h,f,!0)};c.prototype.getBlob=function(f){f==null&&(f=this.Sa,this.Sa+=1);var h=yb(this.Ua,f);f=Cc(this.Ua,f);for(var p=new Uint8Array(h),q=0;q<h;q+=1)p[q]=u[f+
q];return p};c.prototype.get=function(f,h){h=h||{};f!=null&&this.bind(f)&&this.step();f=[];for(var p=zc(this.Ua),q=0;q<p;q+=1)switch(Dc(this.Ua,q)){case 1:var t=h.useBigInt?this.Wb(q):this.Gb(q);f.push(t);break;case 2:f.push(this.Gb(q));break;case 3:f.push(this.Hb(q));break;case 4:f.push(this.getBlob(q));break;default:f.push(null)}return f};c.prototype.tb=function(){for(var f=[],h=yc(this.Ua),p=0;p<h;p+=1)f.push(Ec(this.Ua,p));return f};c.prototype.Fb=function(f,h){var p=this.get(f,h);f=this.tb();
return Object.fromEntries(f.map(function(q,t){return[q,p[t]]}))};c.prototype.$b=function(){return Ba(this.Ua)};c.prototype.Xb=function(){return N(this.Ua)};c.prototype.run=function(f){f!=null&&this.bind(f);this.step();return this.reset()};c.prototype.Bb=function(f,h){h==null&&(h=this.Sa,this.Sa+=1);var p=fa(f);this.qb.push(p);this.db.handleError(tc(this.Ua,h,p,m(f),0))};c.prototype.Mb=function(f,h){h==null&&(h=this.Sa,this.Sa+=1);var p=ea(f.length);u.set(f,p);this.qb.push(p);this.db.handleError(xb(this.Ua,
h,p,f.length,0))};c.prototype.Ab=function(f,h){h==null&&(h=this.Sa,this.Sa+=1);this.db.handleError((f===(f|0)?vc:uc)(this.Ua,h,f))};c.prototype.Pb=function(f){f==null&&(f=this.Sa,this.Sa+=1);xb(this.Ua,f,0,0,0)};c.prototype.Cb=function(f,h){h==null&&(h=this.Sa,this.Sa+=1);switch(typeof f){case "string":this.Bb(f,h);return;case "number":this.Ab(f,h);return;case "bigint":this.Bb(f.toString(),h);return;case "boolean":this.Ab(f+0,h);return;case "object":if(f===null){this.Pb(h);return}if(f.length!=null){this.Mb(f,
h);return}}throw"Wrong API use : tried to bind a value of an unknown type ("+f+").";};c.prototype.Ob=function(f){var h=this;Object.keys(f).forEach(function(p){var q=wc(h.Ua,p);q!==0&&h.Cb(f[p],q)});return!0};c.prototype.Nb=function(f){for(var h=0;h<f.length;h+=1)this.Cb(f[h],h+1);return!0};c.prototype.reset=function(){this.freemem();return Gc(this.Ua)===0&&Fc(this.Ua)===0};c.prototype.freemem=function(){for(var f;(f=this.qb.pop())!==void 0;)y(f)};c.prototype.cb=function(){this.freemem();var f=Hc(this.Ua)===
0;delete this.db.pb[this.Ua];this.Ua=0;return f};e.prototype.next=function(){if(this.jb===null)return{done:!0};this.ab!==null&&(this.ab.cb(),this.ab=null);if(!this.db.db)throw this.kb(),Error("Database closed");var f=na(),h=la(4);oa(v);oa(h);try{this.db.handleError(Ua(this.db.db,this.ob,-1,v,h));this.ob=A(h,"i32");var p=A(v,"i32");if(p===0)return this.kb(),{done:!0};this.ab=new c(p,this.db);this.db.pb[p]=this.ab;return{value:this.ab,done:!1}}catch(q){throw this.wb=B(this.ob),this.kb(),q;}finally{pa(f)}};
e.prototype.kb=function(){y(this.jb);this.jb=null};e.prototype["return"]=function(){this.ab!==null&&(this.ab.cb(),this.ab=null);this.kb();return{done:!0}};e.prototype.Yb=function(){return this.wb!==null?this.wb:B(this.ob)};typeof Symbol==="function"&&typeof Symbol.iterator==="symbol"&&(e.prototype[Symbol.iterator]=function(){return this});g.prototype.run=function(f,h){if(!this.db)throw"Database closed";if(h){f=this.xb(f,h);try{f.step()}finally{f.cb()}}else{f=fa(f);try{this.handleError(Aa(this.db,
f,0,0,v))}finally{y(f)}}return this};g.prototype.exec=function(f,h,p){if(!this.db)throw"Database closed";var q=na(),t=null,w=null,x=null;try{x=w=fa(f);var G=la(4);for(f=[];A(x,"i8")!==0;){oa(v);oa(G);this.handleError(Ua(this.db,x,-1,v,G));var S=A(v,"i32");x=A(G,"i32");if(S!==0){var D=null;t=new c(S,this);for(h!=null&&t.bind(h);t.step();)D===null&&(D={columns:t.tb(),values:[]},f.push(D)),D.values.push(t.get(null,p));t.cb()}}return f}catch(K){throw t&&t.cb(),K;}finally{w&&y(w),pa(q)}};g.prototype.Tb=
function(f,h,p,q,t){typeof h==="function"&&(q=p,p=h,h=void 0);f=this.xb(f,h);try{for(;f.step();)p(f.Fb(null,t))}finally{f.cb()}if(typeof q==="function")return q()};g.prototype.xb=function(f,h){f=fa(f);try{oa(v),this.handleError(Ua(this.db,f,-1,v,0))}finally{y(f)}f=A(v,"i32");if(f===0)throw"Nothing to prepare";var p=new c(f,this);h!=null&&p.bind(h);return this.pb[f]=p};g.prototype.ac=function(f){return new e(f,this)};g.prototype.Vb=function(){if(!this.db)throw Error("Database closed");var f=this.filename+
"_export";ja(f,[]);var h=0,p=0;try{var q=C(f).node,t=null,w=q.Pa.write;q.Pa=Object.create(q.Pa);q.Pa.write=function(S,D,K,U,T){if(t===null)return w(S,D,K,U,T);q.Ta.set(D.subarray(K,K+U),T);q.Va=Math.max(q.Va,T+U);return U};var x=z(f,v);h=A(v,"i32");if(x!==0)throw Error(ia(h));p=ba(h,"main",this.db,"main");if(p===0)throw Error(ia(h));x=za(p,0);if(x===0){var G=this.exec("PRAGMA main.page_count; PRAGMA main.page_size");t=new Uint8Array(G[0].values[0][0]*G[1].values[0][0]);q.Ta=t;x=za(p,-1)}if(x===5||
x===6)throw Error("Unable to export: SQLite is busy or locked. Finish active write transactions before exporting.");if(x!==101)throw Error(ia(h));x=ma(p);p=0;if(x!==0)throw Error(ia(h));x=F(h);if(x!==0)throw Error(ia(h));h=0;t=new Uint8Array(q.Ta.buffer,q.Ta.byteOffset,q.Va);t.length>0&&(t[18]=1,t[19]=1);return t}finally{p!==0&&ma(p),h!==0&&F(h),qa("/"+f)}};g.prototype.close=function(){this.db!==null&&(Object.values(this.pb).forEach(function(f){f.cb()}),this.Xa.forEach(r),this.Xa.clear(),this.eb&&
(ka(this.eb),this.eb=void 0),this.handleError(F(this.db)),qa("/"+this.filename),this.db=null)};g.prototype.handleError=function(f){if(f===0)return null;f=ia(this.db);throw Error(f);};g.prototype.Zb=function(){return ha(this.db)};g.prototype.Sb=function(f,h){var p=n(f,h.length);this.Xa.has(p)&&(r(this.Xa.get(p)),this.Xa.delete(p));var q=ra(function(t,w,x){w=d(w,x);try{var G=h.apply(null,w)}catch(S){a(t,S);return}b(t,G)},"viii");this.Xa.set(p,[q]);this.handleError(zb(this.db,f,h.length,1,0,q,0,0,0));
return this};g.prototype.Rb=function(f,h){function p(D){x.has(D)||x.set(D,q());return x.get(D)}var q=h.init||function(){return null},t=h.finalize||function(D){return D},w=h.step;if(!w)throw"An aggregate function must have a step function in "+f;var x=new Map;h=n(f,w.length-1);this.Xa.has(h)&&(r(this.Xa.get(h)),this.Xa.delete(h));var G=ra(function(D,K,U){var T=Ab(D,1),Wa=p(T);K=d(K,U);Wa=[Wa].concat(K);try{x.set(T,w.apply(null,Wa))}catch(Ic){x.delete(T),a(D,Ic)}},"viii"),S=ra(function(D){var K=Ab(D,
1);try{var U=t(p(K))}catch(T){x.delete(K);a(D,T);return}b(D,U);x.delete(K)},"vi");this.Xa.set(h,[G,S]);this.handleError(zb(this.db,f,w.length-1,1,0,0,G,S,0));return this};g.prototype.hc=function(f){this.eb&&(Bb(this.db,0,0),ka(this.eb),this.eb=void 0);if(!f)return this;this.eb=ra(function(h,p,q,t,w){switch(p){case 18:h="insert";break;case 23:h="update";break;case 9:h="delete";break;default:throw"unknown operationCode in updateHook callback: "+p;}q=B(q);t=B(t);if(w>Number.MAX_SAFE_INTEGER)throw"rowId too big to fit inside a Number";
f(h,q,t,Number(w))},"viiiij");Bb(this.db,this.eb,0);return this};c.prototype.bind=c.prototype.bind;c.prototype.step=c.prototype.step;c.prototype.get=c.prototype.get;c.prototype.getColumnNames=c.prototype.tb;c.prototype.getAsObject=c.prototype.Fb;c.prototype.getSQL=c.prototype.$b;c.prototype.getNormalizedSQL=c.prototype.Xb;c.prototype.run=c.prototype.run;c.prototype.reset=c.prototype.reset;c.prototype.freemem=c.prototype.freemem;c.prototype.free=c.prototype.cb;e.prototype.next=e.prototype.next;e.prototype.getRemainingSQL=
e.prototype.Yb;g.prototype.run=g.prototype.run;g.prototype.exec=g.prototype.exec;g.prototype.each=g.prototype.Tb;g.prototype.prepare=g.prototype.xb;g.prototype.iterateStatements=g.prototype.ac;g.prototype["export"]=g.prototype.Vb;g.prototype.close=g.prototype.close;g.prototype.handleError=g.prototype.handleError;g.prototype.getRowsModified=g.prototype.Zb;g.prototype.create_function=g.prototype.Sb;g.prototype.create_aggregate=g.prototype.Rb;g.prototype.updateHook=g.prototype.hc;k.Database=g};
var sa="./this.program",ta=(a,b)=>{throw b;},ua=globalThis.document?.currentScript?.src;typeof __filename!="undefined"?ua=__filename:ca&&(ua=self.location.href);var va="",wa,xa;
if(da){var fs=require("node:fs");va=__dirname+"/";xa=a=>{a=ya(a)?new URL(a):a;return fs.readFileSync(a)};wa=async a=>{a=ya(a)?new URL(a):a;return fs.readFileSync(a,void 0)};process.argv.length>1&&(sa=process.argv[1].replace(/\\/g,"/"));process.argv.slice(2);typeof module!="undefined"&&(module.exports=k);ta=(a,b)=>{process.exitCode=a;throw b;}}else if(aa||ca){try{va=(new URL(".",ua)).href}catch{}ca&&(xa=a=>{var b=new XMLHttpRequest;b.open("GET",a,!1);b.responseType="arraybuffer";b.send(null);return new Uint8Array(b.response)});
wa=async a=>{if(ya(a))return new Promise((d,c)=>{var e=new XMLHttpRequest;e.open("GET",a,!0);e.responseType="arraybuffer";e.onload=()=>{e.status==200||e.status==0&&e.response?d(e.response):c(e.status)};e.onerror=c;e.send(null)});var b=await fetch(a,{credentials:"same-origin"});if(b.ok)return b.arrayBuffer();throw Error(b.status+" : "+b.url);}}var Ca=console.log.bind(console),E=console.error.bind(console),Da,Ea=!1,Fa,ya=a=>a.startsWith("file://");
function Ga(){if(!u?.buffer?.resizable){var a=Ha.buffer;u=new Int8Array(a);Ia=new Int16Array(a);H=new Uint8Array(a);I=new Int32Array(a);J=new Uint32Array(a);Ja=new Float32Array(a);Ka=new Float64Array(a);L=new BigInt64Array(a)}}function La(){var a=k.preRun;a&&(typeof a=="function"&&(a=[a]),Ma.push(...a));for(a=Ma;a.length>0;)a.shift()(k)}function Na(){var a=k.postRun;a&&(typeof a=="function"&&(a=[a]),Oa.push(...a));for(a=Oa;a.length>0;)a.shift()(k)}
function Pa(a){k.onAbort?.(a);a=`Aborted(${a})`;E(a);Ea=!0;throw new WebAssembly.RuntimeError(a+". Build with -sASSERTIONS for more info.");}var Qa;async function Ra(a){if(!Da)try{var b=await wa(a);return new Uint8Array(b)}catch{}if(a==Qa&&Da)a=new Uint8Array(Da);else if(xa)a=xa(a);else throw"both async and sync fetching of the wasm failed";return a}
async function Sa(a,b){try{var d=await Ra(a);return await WebAssembly.instantiate(d,b)}catch(c){E(`failed to asynchronously prepare wasm: ${c}`),Pa(c)}}async function Ta(a){var b=Qa;if(!Da&&!ya(b)&&!da)try{var d=fetch(b,{credentials:"same-origin"});return await WebAssembly.instantiateStreaming(d,a)}catch(c){E(`wasm streaming compile failed: ${c}`),E("falling back to ArrayBuffer instantiation")}return Sa(b,a)}
class Va{name="ExitStatus";constructor(a){this.message=`Program terminated with exit(${a})`;this.status=a}}
var u,Oa=[],Ma=[],Xa=!0,Ya=new TextDecoder,Za=(a,b,d,c)=>{d=b+d;if(c)return d;for(;a[b]&&!(b>=d);)++b;return b},H,B=(a,b,d)=>a?Ya.decode(H.subarray(a,Za(H,a,b,d))):"",$a=(a,b)=>{for(var d=0,c=a.length-1;c>=0;c--){var e=a[c];e==="."?a.splice(c,1):e===".."?(a.splice(c,1),d++):d&&(a.splice(c,1),d--)}if(b)for(;d;d--)a.unshift("..");return a},ab=a=>{var b=a.charAt(0)==="/",d=a.slice(-1)==="/";(a=$a(a.split("/").filter(c=>!!c),!b).join("/"))||b||(a=".");a&&d&&(a+="/");return(b?"/":"")+a},bb=a=>{var b=/^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/.exec(a).slice(1);
a=b[0];b=b[1];if(!a&&!b)return".";b&&=b.slice(0,-1);return a+b},cb=a=>a&&a.match(/([^\/]+|\/)\/*$/)[1],db=()=>{if(da){var a=require("node:crypto");return b=>(a.randomFillSync(b),0)}return b=>(crypto.getRandomValues(b),0)},eb=a=>(eb=db())(a),fb=(...a)=>{for(var b="",d=!1,c=a.length-1;c>=-1&&!d;c--){d=c>=0?a[c]:"/";if(typeof d!="string")throw new TypeError("Arguments to path.resolve must be strings");if(!d)return"";b=d+"/"+b;d=d.charAt(0)==="/"}b=$a(b.split("/").filter(e=>!!e),!d).join("/");return(d?
"/":"")+b||"."},gb=a=>{var b=Za(a,0);return Ya.decode(a.buffer?a.subarray(0,b):new Uint8Array(a.slice(0,b)))},hb=[],m=a=>{for(var b=0,d=0;d<a.length;++d){var c=a.charCodeAt(d);c<=127?b++:c<=2047?b+=2:c>=55296&&c<=57343?(b+=4,++d):b+=3}return b},M=(a,b,d,c)=>{if(!(c>0))return 0;var e=d;c=d+c-1;for(var g=0;g<a.length;++g){var n=a.codePointAt(g);if(n<=127){if(d>=c)break;b[d++]=n}else if(n<=2047){if(d+1>=c)break;b[d++]=192|n>>6;b[d++]=128|n&63}else if(n<=65535){if(d+2>=c)break;b[d++]=224|n>>12;b[d++]=
128|n>>6&63;b[d++]=128|n&63}else{if(d+3>=c)break;b[d++]=240|n>>18;b[d++]=128|n>>12&63;b[d++]=128|n>>6&63;b[d++]=128|n&63;g++}}b[d]=0;return d-e},ib=a=>{var b=Array(m(a)+1);a=M(a,b,0,b.length);b.length=a;return b},jb=[];function kb(a,b){jb[a]={input:[],output:[],ib:b};lb(a,mb)}
var mb={open(a){var b=jb[a.node.rdev];if(!b)throw new O(43);a.tty=b;a.seekable=!1},close(a){a.tty.ib.fsync(a.tty)},fsync(a){a.tty.ib.fsync(a.tty)},read(a,b,d,c){if(!a.tty||!a.tty.ib.Ib)throw new O(60);for(var e=0,g=0;g<c;g++){try{var n=a.tty.ib.Ib(a.tty)}catch(r){throw new O(29);}if(n===void 0&&!e)throw new O(6);if(n===null||n===void 0)break;e++;b[d+g]=n;if(n===10)break}e&&(a.node.atime=Date.now());return e},write(a,b,d,c){if(!a.tty||!a.tty.ib.yb)throw new O(60);try{for(var e=0;e<c;e++)a.tty.ib.yb(a.tty,
b[d+e])}catch(g){throw new O(29);}c&&(a.node.mtime=a.node.ctime=Date.now());return e}},nb={Ib(){a:{if(!hb.length){var a=null;if(da){var b=Buffer.alloc(256),d=0;try{d=fs.readSync(process.stdin.fd,b,0,256)}catch(c){if(c.toString().includes("EOF"))d=0;else throw c;}d>0&&(a=b.toString("utf-8",0,d))}else globalThis.window?.prompt&&(a=window.prompt("Input: "),a!==null&&(a+="\n"));if(!a){a=null;break a}hb=ib(a)}a=hb.shift()}return a},yb(a,b){b===null||b===10?(Ca(gb(a.output)),a.output=[]):b!=0&&a.output.push(b)},
fsync(a){a.output?.length>0&&(Ca(gb(a.output)),a.output=[])},qc(){return{lc:25856,nc:5,kc:191,mc:35387,jc:[3,28,127,21,4,0,1,0,17,19,26,0,18,15,23,22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}},rc(){return 0},sc(){return[24,80]}},ob={yb(a,b){b===null||b===10?(E(gb(a.output)),a.output=[]):b!=0&&a.output.push(b)},fsync(a){a.output?.length>0&&(E(gb(a.output)),a.output=[])}},P={Za:null,bb(){return P.createNode(null,"/",16895,0)},createNode(a,b,d,c){if((d&61440)===24576||(d&61440)===4096)throw new O(63);P.Za||
(P.Za={dir:{node:{Wa:P.Qa.Wa,$a:P.Qa.$a,lookup:P.Qa.lookup,lb:P.Qa.lb,rename:P.Qa.rename,unlink:P.Qa.unlink,rmdir:P.Qa.rmdir,readdir:P.Qa.readdir,symlink:P.Qa.symlink},stream:{Ya:P.Pa.Ya}},file:{node:{Wa:P.Qa.Wa,$a:P.Qa.$a},stream:{Ya:P.Pa.Ya,read:P.Pa.read,write:P.Pa.write,mb:P.Pa.mb,nb:P.Pa.nb}},link:{node:{Wa:P.Qa.Wa,$a:P.Qa.$a,readlink:P.Qa.readlink},stream:{}},Db:{node:{Wa:P.Qa.Wa,$a:P.Qa.$a},stream:pb}});d=qb(a,b,d,c);Q(d.mode)?(d.Qa=P.Za.dir.node,d.Pa=P.Za.dir.stream,d.Ta={}):(d.mode&61440)===
32768?(d.Qa=P.Za.file.node,d.Pa=P.Za.file.stream,d.Va=0,d.Ta=P.Ub??(P.Ub=new Uint8Array(0))):(d.mode&61440)===40960?(d.Qa=P.Za.link.node,d.Pa=P.Za.link.stream):(d.mode&61440)===8192&&(d.Qa=P.Za.Db.node,d.Pa=P.Za.Db.stream);d.atime=d.mtime=d.ctime=Date.now();a&&(a.Ta[b]=d,a.atime=a.mtime=a.ctime=d.atime);return d},Qa:{Wa(a){var b={};b.dev=(a.mode&61440)===8192?a.id:1;b.ino=a.id;b.mode=a.mode;b.nlink=1;b.uid=0;b.gid=0;b.rdev=a.rdev;Q(a.mode)?b.size=4096:(a.mode&61440)===32768?b.size=a.Va:(a.mode&61440)===
40960?b.size=a.link.length:b.size=0;b.atime=new Date(a.atime);b.mtime=new Date(a.mtime);b.ctime=new Date(a.ctime);b.atimeMs=a.atime;b.mtimeMs=a.mtime;b.ctimeMs=a.ctime;b.blksize=4096;b.blocks=Math.ceil(b.size/b.blksize);return b},$a(a,b){for(var d of["mode","atime","mtime","ctime"])b[d]!=null&&(a[d]=b[d]);b.size!==void 0&&(b=b.size,a.Va!=b&&(d=a.Ta,a.Ta=new Uint8Array(b),a.Ta.set(d.subarray(0,Math.min(b,a.Va))),a.Va=b))},lookup(){P.rb||(P.rb=new O(44),P.rb.stack="<generic error, no stack>");throw P.rb;
},lb(a,b,d,c){return P.createNode(a,b,d,c)},rename(a,b,d){try{var c=rb(b,d)}catch(g){}if(c&&Q(a.mode))for(var e in c.Ta)throw new O(55);delete a.parent.Ta[a.name];b.Ta[d]=a;a.name=d;b.ctime=b.mtime=a.parent.ctime=a.parent.mtime=Date.now()},unlink(a,b){delete a.Ta[b];a.ctime=a.mtime=Date.now()},rmdir(a,b){var d=rb(a,b),c;for(c in d.Ta)throw new O(55);delete a.Ta[b];a.ctime=a.mtime=Date.now()},readdir(a){return[".","..",...Object.keys(a.Ta)]},symlink(a,b,d){a=P.createNode(a,b,41471,0);a.link=d;return a},
readlink(a){if((a.mode&61440)!==40960)throw new O(28);return a.link}},Pa:{read(a,b,d,c,e){if(e>=a.node.Va)return 0;c=Math.min(a.node.Va-e,c);b.set(a.node.Ta.subarray(e,e+c),d);return c},write(a,b,d,c,e,g){b.buffer===u.buffer&&(g=!1);if(!c)return 0;a=a.node;a.mtime=a.ctime=Date.now();if(g)a.Ta=b.subarray(d,d+c),a.Va=c;else if(a.Va||e){g=e+c;var n=a.Ta.length;n>=g||(g=Math.max(g,n*(n<1048576?2:1.125)>>>0),n&&(g=Math.max(g,256)),n=a.Ta.subarray(0,a.Va),a.Ta=new Uint8Array(g),a.Ta.set(n));a.Ta.set(b.subarray(d,
d+c),e);a.Va=Math.max(a.Va,e+c)}else a.Ta=b.slice(d,d+c),a.Va=c;return c},Ya(a,b,d){d===1?b+=a.position:d===2&&(a.node.mode&61440)===32768&&(b+=a.node.Va);if(b<0)throw new O(28);return b},mb(a,b,d,c,e){if((a.node.mode&61440)!==32768)throw new O(43);a=a.node.Ta;if(e&2||a.buffer!==u.buffer){e=!0;c=Math.ceil(b/65536)*65536;var g=sb(65536,c);g&&H.fill(0,g,g+c);c=g;if(!c)throw new O(48);if(a){if(d>0||d+b<a.length)a.subarray?a=a.subarray(d,d+b):a=Array.prototype.slice.call(a,d,d+b);u.set(a,c)}}else e=!1,
c=a.byteOffset;return{ec:c,Lb:e}},nb(a,b,d,c){P.Pa.write(a,b,0,c,d,!1);return 0}}},wb=(a,b)=>{var d=0;a&&(d|=365);b&&(d|=146);return d},Cb=null,Db={},Eb=[],Fb=1,R=[],Gb=!1,Hb=!0,Ib={},O=class{name="ErrnoError";constructor(a){this.Ra=a}},Jb=class{shared={};node=null;get flags(){return this.shared.flags}set flags(a){this.shared.flags=a}get position(){return this.shared.position}set position(a){this.shared.position=a}},Kb=class{Qa={};Pa={};gb=null;listeners=null;zb=0;constructor(a,b,d,c){a||=this;this.parent=
a;this.bb=a.bb;this.id=Fb++;this.name=b;this.mode=d;this.rdev=c;this.atime=this.mtime=this.ctime=Date.now()}get read(){return(this.mode&365)===365}set read(a){a?this.mode|=365:this.mode&=-366}get write(){return(this.mode&146)===146}set write(a){a?this.mode|=146:this.mode&=-147}dc(){if(this.listeners){var a;for(b of this.listeners)b.exclusive?(a||=[]).push(b):b.Qb(32);if(a){var b=(this.zb||0)%a.length;this.zb=b+1;a[b].Qb(32)}}}};
function C(a,b={}){if(!a)throw new O(44);b.sb??(b.sb=!0);a.charAt(0)==="/"||(a="//"+a);var d=0;a:for(;d<40;d++){a=a.split("/").filter(r=>!!r);for(var c=Cb,e="/",g=0;g<a.length;g++){var n=g===a.length-1;if(n&&b.parent)break;if(a[g]!==".")if(a[g]==="..")if(e=bb(e),c===c.parent){a=e+"/"+a.slice(g+1).join("/");d--;continue a}else c=c.parent;else{e=ab(e+"/"+a[g]);try{c=rb(c,a[g])}catch(r){if(r?.Ra===44&&n&&b.cc)return{path:e};throw r;}!c.gb||n&&!b.sb||(c=c.gb.root);if((c.mode&61440)===40960&&(!n||b.fb)){if(!c.Qa.readlink)throw new O(52);
c=c.Qa.readlink(c);c.charAt(0)==="/"||(c=bb(e)+"/"+c);a=c+"/"+a.slice(g+1).join("/");continue a}}}return{path:e,node:c}}throw new O(32);}function Lb(a){for(var b;;){if(a===a.parent)return a=a.bb.Kb,b?a[a.length-1]!=="/"?`${a}/${b}`:a+b:a;b=b?`${a.name}/${b}`:a.name;a=a.parent}}function Mb(a,b){for(var d=0,c=0;c<b.length;c++)d=(d<<5)-d+b.charCodeAt(c)|0;return(a+d>>>0)%R.length}
function Nb(a){var b=Mb(a.parent.id,a.name);if(R[b]===a)R[b]=a.hb;else for(b=R[b];b;){if(b.hb===a){b.hb=a.hb;break}b=b.hb}}function rb(a,b){var d=Q(a.mode)?(d=Ob(a,"x"))?d:a.Qa.lookup?0:2:54;if(d)throw new O(d);for(d=R[Mb(a.id,b)];d;d=d.hb){var c=d.name;if(d.parent.id===a.id&&c===b)return d}return a.Qa.lookup(a,b)}function qb(a,b,d,c){a=new Kb(a,b,d,c);b=Mb(a.parent.id,a.name);a.hb=R[b];return R[b]=a}function Q(a){return(a&61440)===16384}
function Ob(a,b){return Hb?0:b.includes("r")&&!(a.mode&292)||b.includes("w")&&!(a.mode&146)||b.includes("x")&&!(a.mode&73)?2:0}function Pb(a,b){if(!Q(a.mode))return 54;try{return rb(a,b),20}catch(d){}return Ob(a,"wx")}function Qb(a,b,d){try{var c=rb(a,b)}catch(e){return e.Ra}if(a=Ob(a,"wx"))return a;if(d){if(!Q(c.mode))return 54;if(c===c.parent||Lb(c)==="/")return 10}else if(Q(c.mode))return 31;return 0}function Rb(a){if(!a)throw new O(63);return a}
function V(a){a=Eb[a];if(!a)throw new O(8);return a}function Sb(a,b=-1){a=Object.assign(new Jb,a);if(b==-1)a:{for(b=0;b<=4096;b++)if(!Eb[b])break a;throw new O(33);}a.fd=b;return Eb[b]=a}function Tb(a,b=-1){a=Sb(a,b);a.Pa?.oc?.(a);return a}function Ub(a,b,d){var c=a?.Pa.$a;a=c?a:b;c??=b.Qa.$a;Rb(c);try{c(a,d)}catch(e){if(e instanceof RangeError)throw new O(22);throw e;}}var pb={open(a){a.Pa=Db[a.node.rdev].Pa;a.Pa.open?.(a)},Ya(){throw new O(70);}};function lb(a,b){Db[a]={Pa:b}}
function Vb(a,b){var d=b==="/";if(d&&Cb)throw new O(10);if(!d&&b){var c=C(b,{sb:!1});b=c.path;c=c.node;if(c.gb)throw new O(10);if(!Q(c.mode))throw new O(54);}b={type:a,tc:{},Kb:b,bc:[]};a=a.bb(b);a.bb=b;b.root=a;d?Cb=a:c&&(c.gb=b,c.bb&&c.bb.bc.push(b))}function Wb(a,b,d){var c=C(a,{parent:!0}).node;a=cb(a);if(!a)throw new O(28);if(a==="."||a==="..")throw new O(20);var e=Pb(c,a);if(e)throw new O(e);if(!c.Qa.lb)throw new O(63);return c.Qa.lb(c,a,b,d)}
function Xb(a,b=438){return Wb(a,b&4095|32768,0)}function W(a,b=511){return Wb(a,b&1023|16384,0)}function Yb(a,b,d){typeof d=="undefined"&&(d=b,b=438);Wb(a,b|8192,d)}function Zb(a,b){if(!fb(a))throw new O(44);var d=C(b,{parent:!0}).node;if(!d)throw new O(44);b=cb(b);var c=Pb(d,b);if(c)throw new O(c);if(!d.Qa.symlink)throw new O(63);d.Qa.symlink(d,b,a)}
function $b(a){var b=C(a,{parent:!0}).node;a=cb(a);var d=rb(b,a),c=Qb(b,a,!0);if(c)throw new O(c);if(!b.Qa.rmdir)throw new O(63);if(d.gb)throw new O(10);b.Qa.rmdir(b,a);Nb(d)}function qa(a){var b=C(a,{parent:!0}).node;if(!b)throw new O(44);a=cb(a);var d=rb(b,a),c=Qb(b,a,!1);if(c)throw new O(c);if(!b.Qa.unlink)throw new O(63);if(d.gb)throw new O(10);b.Qa.unlink(b,a);Nb(d)}function ac(a,b=!1){a=C(a,{fb:!b}).node;return Rb(a.Qa.Wa)(a)}
function bc(a,b,d){Ub(a,b,{mode:d&4095|b.mode&-4096,ctime:Date.now(),Eb:!1})}function cc(a,b){a=typeof a=="string"?C(a,{fb:!0}).node:a;bc(null,a,b)}function dc(a,b,d){if(Q(b.mode))throw new O(31);if((b.mode&61440)!==32768)throw new O(28);var c=Ob(b,"w");if(c)throw new O(c);Ub(a,b,{size:d,timestamp:Date.now()})}function ec(a,b,d,c=!1){a=C(a,{fb:!c});Ub(null,a.node,{atime:b,mtime:d,Eb:c})}
function fc(a,b,d=438){if(a==="")throw new O(44);if(typeof b=="string"){var c={r:0,"r+":2,w:577,"w+":578,a:1089,"a+":1090}[b];if(typeof c=="undefined")throw Error(`Unknown file open mode: ${b}`);b=c}d=b&64?d&4095|32768:0;if(typeof a=="object")c=a;else{var e=a.endsWith("/");a=C(a,{fb:!(b&131072),cc:!0});c=a.node;a=a.path}var g=!1;if(b&64)if(c){if(b&128)throw new O(20);}else{if(e)throw new O(31);c=Wb(a,d|511,0);g=!0}if(!c)throw new O(44);(c.mode&61440)===8192&&(b&=-513);if(b&65536&&!Q(c.mode))throw new O(54);
if(!g&&(c?(c.mode&61440)===40960?e=32:(e=["r","w","rw"][b&3],b&512&&(e+="w"),e=Q(c.mode)&&(e!=="r"||b&576)?31:Ob(c,e)):e=44,e))throw new O(e);b&512&&!g&&(e=c,e=typeof e=="string"?C(e,{fb:!0}).node:e,dc(null,e,0));b&=-131713;e=Sb({node:c,path:Lb(c),flags:b,seekable:!0,position:0,Pa:c.Pa,fc:[],error:!1});e.Pa.open&&e.Pa.open(e);g&&cc(c,d&511);!k.logReadFiles||b&1||a in Ib||(Ib[a]=1,E(`read file: ${a}`));return e}
function hc(a){if(a.fd===null)throw new O(8);a.ub&&(a.ub=null);a.node?.dc();try{a.Pa.close&&a.Pa.close(a)}catch(b){throw b;}finally{Eb[a.fd]=null}a.fd=null}function ic(a,b,d){if(a.fd===null)throw new O(8);if(!a.seekable||!a.Pa.Ya)throw new O(70);if(d!=0&&d!=1&&d!=2)throw new O(28);a.position=a.Pa.Ya(a,b,d);a.fc=[]}
function jc(a,b,d,c,e){if(c<0||e<0)throw new O(28);if(a.fd===null)throw new O(8);if((a.flags&2097155)===0)throw new O(8);if(Q(a.node.mode))throw new O(31);if(!a.Pa.write)throw new O(28);a.seekable&&a.flags&1024&&ic(a,0,2);var g=typeof e!="undefined";if(!g)e=a.position;else if(!a.seekable)throw new O(70);b=a.Pa.write(a,b,d,c,e,void 0);g||(a.position+=b);return b}
function Jc(){var a,b,d;Gb=!0;a??=k.stdin;b??=k.stdout;d??=k.stderr;a?X("stdin",a):Zb("/dev/tty","/dev/stdin");b?X("stdout",null,b):Zb("/dev/tty","/dev/stdout");d?X("stderr",null,d):Zb("/dev/tty1","/dev/stderr");fc("/dev/stdin",0);fc("/dev/stdout",1);fc("/dev/stderr",1)}
function ja(a,b){var d="/",c=a;d&&(d=typeof d=="string"?d:Lb(d),c=a?ab(d+"/"+a):d);a=wb(!0,!0);c=Xb(c,a);b&&(typeof b=="string"&&(b=ib(b)),b.subarray||(b=new Uint8Array(b)),cc(c,a|146),d=fc(c,577),jc(d,b,0,b.length,0),hc(d),cc(c,a))}
function X(a,b,d){a=ab("/dev/"+a);var c=wb(!!b,!!d);X.Jb??(X.Jb=64);var e=X.Jb++<<8|0;lb(e,{open(g){g.seekable=!1},close(){d?.buffer?.length&&d(10)},read(g,n,r,v){for(var l=0,z=0;z<v;z++){try{var F=b()}catch(ba){throw new O(29);}if(F===void 0&&!l)throw new O(6);if(F===null||F===void 0)break;l++;n[r+z]=F}l&&(g.node.atime=Date.now());return l},write(g,n,r,v){for(var l=0;l<v;l++)try{d(n[r+l])}catch(z){throw new O(29);}v&&(g.node.mtime=g.node.ctime=Date.now());return l}});Yb(a,c,e)}var Y={},I,J,L;
function Kc(a,b,d=!1){if(b.charAt(0)==="/")return b;a=a===-100?"/":V(a).path;if(b.length==0){if(!d)throw new O(44);return a}return a+"/"+b}
function Lc(a,b){J[a>>2]=b.dev;J[a+4>>2]=b.mode;J[a+8>>2]=b.nlink;J[a+12>>2]=b.uid;J[a+16>>2]=b.gid;J[a+20>>2]=b.rdev;L[a+24>>3]=BigInt(b.size);I[a+32>>2]=4096;I[a+36>>2]=b.blocks;var d=b.atimeMs??b.atime.getTime(),c=b.mtimeMs??b.mtime.getTime(),e=b.ctimeMs??b.ctime.getTime();L[a+40>>3]=BigInt(Math.floor(d/1E3));J[a+48>>2]=Math.floor(d%1E3*1E6);L[a+56>>3]=BigInt(Math.floor(c/1E3));J[a+64>>2]=Math.floor(c%1E3*1E6);L[a+72>>3]=BigInt(Math.floor(e/1E3));J[a+80>>2]=Math.floor(e%1E3*1E6);L[a+88>>3]=BigInt(b.ino);
return 0}
var Mc=void 0,Nc=()=>{var a=I[+Mc>>2];Mc+=4;return a},Ia,Oc=0,Pc=[0,31,60,91,121,152,182,213,244,274,305,335],Qc=[0,31,59,90,120,151,181,212,243,273,304,334],Rc={},Sc=a=>{Fa=a;Xa||Oc>0||(k.onExit?.(a),Ea=!0);ta(a,new Va(a))},Tc={},Vc=()=>{if(!Uc){var a={USER:"web_user",LOGNAME:"web_user",PATH:"/",PWD:"/",HOME:"/home/web_user",LANG:(globalThis.navigator?.language??"C").replace("-","_")+".UTF-8",_:sa},b;for(b in Tc)Tc[b]===void 0?delete a[b]:a[b]=Tc[b];var d=[];for(b in a)d.push(`${b}=${a[b]}`);Uc=
d}return Uc},Uc,Ja,Ka;function A(a,b="i8"){b.endsWith("*")&&(b="*");switch(b){case "i1":return u[a];case "i8":return u[a];case "i16":return Ia[a>>1];case "i32":return I[a>>2];case "i64":return L[a>>3];case "float":return Ja[a>>2];case "double":return Ka[a>>3];case "*":return J[a>>2];default:Pa(`invalid type for getValue: ${b}`)}}
function oa(a){var b="i32";b.endsWith("*")&&(b="*");switch(b){case "i1":u[a]=0;break;case "i8":u[a]=0;break;case "i16":Ia[a>>1]=0;break;case "i32":I[a>>2]=0;break;case "i64":L[a>>3]=BigInt(0);break;case "float":Ja[a>>2]=0;break;case "double":Ka[a>>3]=0;break;case "*":J[a>>2]=0;break;default:Pa(`invalid type for setValue: ${b}`)}}
var Wc=(a,b,d,c)=>{var e={string:l=>{var z=0;if(l!==null&&l!==void 0&&l!==0){z=m(l)+1;var F=la(z);M(l,H,F,z);z=F}return z},array:l=>{var z=la(l.length);u.set(l,z);return z}};a=k["_"+a];var g=[],n=0;if(c)for(var r=0;r<c.length;r++){var v=e[d[r]];v?(n||=na(),g[r]=v(c[r])):g[r]=c[r]}d=a(...g);return d=function(l){n&&pa(n);return b==="string"?B(l):b==="boolean"?!!l:l}(d)},fa=a=>{var b=m(a)+1,d=ea(b);d&&M(a,H,d,b);return d},Xc,Yc=[],ka=a=>{Xc.delete(Z.get(a));Z.set(a,null);Yc.push(a)},Zc=a=>{var b=a.length;
return[b%128|128,b>>7,...a]},$c={i:127,p:127,j:126,f:125,d:124,e:111},ad=a=>Zc(Array.from(a,b=>$c[b])),ra=(a,b)=>{if(!Xc){Xc=new WeakMap;var d=Z.length;if(Xc)for(var c=0;c<0+d;c++){var e=Z.get(c);e&&Xc.set(e,c)}}if(d=Xc.get(a)||0)return d;d=Yc.length?Yc.pop():Z.grow(1);try{Z.set(d,a)}catch(g){if(!(g instanceof TypeError))throw g;b=Uint8Array.of(0,97,115,109,1,0,0,0,1,...Zc([1,96,...ad(b.slice(1)),...ad(b[0]==="v"?"":b[0])]),2,7,1,1,101,1,102,0,0,7,5,1,1,102,0,0);b=new WebAssembly.Module(b);b=(new WebAssembly.Instance(b,
{e:{f:a}})).exports.f;Z.set(d,b)}Xc.set(a,d);return d};R.length=4096;Vb(P,"/");W("/tmp");W("/home");W("/home/web_user");(function(){W("/dev");lb(259,{read:()=>0,write:(c,e,g,n)=>n,Ya:()=>0});Yb("/dev/null",259);kb(1280,nb);kb(1536,ob);Yb("/dev/tty",1280);Yb("/dev/tty1",1536);var a=new Uint8Array(1024),b=0,d=()=>{b||(eb(a),b=a.byteLength);return a[--b]};X("random",d);X("urandom",d);W("/dev/shm");W("/dev/shm/tmp")})();
(function(){W("/proc");var a=W("/proc/self");W("/proc/self/fd");Vb({bb(){var b=qb(a,"fd",16895,73);b.Pa={Ya:P.Pa.Ya};b.Qa={lookup(d,c){d=+c;var e=V(d);d={parent:null,bb:{Kb:"fake"},Qa:{readlink:()=>e.path},id:d+1};return d.parent=d},readdir(){return Array.from(Eb.entries()).filter(([,d])=>d).map(([d])=>d.toString())}};return b}},"/proc/self/fd")})();k.noExitRuntime&&(Xa=k.noExitRuntime);k.print&&(Ca=k.print);k.printErr&&(E=k.printErr);k.wasmBinary&&(Da=k.wasmBinary);k.thisProgram&&(sa=k.thisProgram);
var bd=k.preInit;if(bd)for(typeof bd=="function"&&(k.preInit=bd=[bd]);bd.length>0;)bd.shift()();k.stackSave=()=>na();k.stackRestore=a=>pa(a);k.stackAlloc=a=>la(a);k.cwrap=(a,b,d,c)=>{var e=!d||d.every(g=>g==="number"||g==="boolean");return b!=="string"&&e&&!c?k["_"+a]:(...g)=>Wc(a,b,d,g)};k.addFunction=ra;k.removeFunction=ka;k.UTF8ToString=B;k.lengthBytesUTF8=m;k.stringToNewUTF8=fa;k.writeArrayToMemory=(a,b)=>{u.set(a,b)};
var ea,y,sb,cd,pa,la,na,Ha,Z,dd={a:(a,b,d,c)=>Pa(`Assertion failed: ${B(a)}, at: `+[b?B(b):"unknown filename",d,c?B(c):"unknown function"]),i:function(a,b){try{return a=B(a),cc(a,b),0}catch(d){if(typeof Y=="undefined"||d.name!=="ErrnoError")throw d;return-d.Ra}},M:function(a,b,d){try{b=B(b);b=Kc(a,b);if(d&-8)return-28;var c=C(b,{fb:!0}).node;if(!c)return-44;a="";d&4&&(a+="r");d&2&&(a+="w");d&1&&(a+="x");return a&&Ob(c,a)?-2:0}catch(e){if(typeof Y=="undefined"||e.name!=="ErrnoError")throw e;return-e.Ra}},
j:function(a,b){try{var d=V(a);bc(d,d.node,b);return 0}catch(c){if(typeof Y=="undefined"||c.name!=="ErrnoError")throw c;return-c.Ra}},h:function(a){try{var b=V(a);Ub(b,b.node,{timestamp:Date.now(),Eb:!1});return 0}catch(d){if(typeof Y=="undefined"||d.name!=="ErrnoError")throw d;return-d.Ra}},b:function(a,b,d){Mc=d;try{var c=V(a);switch(b){case 0:var e=Nc();if(e<0)break;for(;Eb[e];)e++;return Tb(c,e).fd;case 1:case 2:return 0;case 3:return c.flags;case 4:return e=Nc(),c.flags=c.flags&-289793|e&289792,
0;case 12:return e=Nc(),Ia[e+0>>1]=2,0;case 13:case 14:return 0}return-28}catch(g){if(typeof Y=="undefined"||g.name!=="ErrnoError")throw g;return-g.Ra}},g:function(a,b){try{var d=V(a),c=d.node,e=d.Pa.Wa;a=e?d:c;e??=c.Qa.Wa;Rb(e);var g=e(a);return Lc(b,g)}catch(n){if(typeof Y=="undefined"||n.name!=="ErrnoError")throw n;return-n.Ra}},I:function(a,b){b=b<-9007199254740992||b>9007199254740992?NaN:Number(b);try{if(isNaN(b))return-22;var d=V(a);if(b<0||(d.flags&2097155)===0)throw new O(28);dc(d,d.node,
b);return 0}catch(c){if(typeof Y=="undefined"||c.name!=="ErrnoError")throw c;return-c.Ra}},H:function(a,b){try{if(!b)return-28;var d=m("/")+1;if(b<d)return-68;M("/",H,a,b);return d}catch(c){if(typeof Y=="undefined"||c.name!=="ErrnoError")throw c;return-c.Ra}},E:()=>0,L:function(a,b){try{return a=B(a),Lc(b,ac(a,!0))}catch(d){if(typeof Y=="undefined"||d.name!=="ErrnoError")throw d;return-d.Ra}},C:function(a,b,d){try{return b=B(b),b=Kc(a,b),W(b,d&-19),0}catch(c){if(typeof Y=="undefined"||c.name!=="ErrnoError")throw c;
return-c.Ra}},K:function(a,b,d,c){try{b=B(b);var e=c&256;b=Kc(a,b,c&4096);return Lc(d,e?ac(b,!0):ac(b))}catch(g){if(typeof Y=="undefined"||g.name!=="ErrnoError")throw g;return-g.Ra}},x:function(a,b,d,c){Mc=c;try{b=B(b);b=Kc(a,b);var e=c?Nc():0;d&64&&(e&=-19);return fc(b,d,e).fd}catch(g){if(typeof Y=="undefined"||g.name!=="ErrnoError")throw g;return-g.Ra}},s:function(a,b,d,c){try{b=B(b);b=Kc(a,b);if(c<=0)return-28;var e=C(b).node;if(!e)throw new O(44);if(!e.Qa.readlink)throw new O(28);var g=e.Qa.readlink(e);
var n=Math.min(c,m(g)),r=u[d+n];M(g,H,d,c+1);u[d+n]=r;return n}catch(v){if(typeof Y=="undefined"||v.name!=="ErrnoError")throw v;return-v.Ra}},r:function(a){try{return a=B(a),$b(a),0}catch(b){if(typeof Y=="undefined"||b.name!=="ErrnoError")throw b;return-b.Ra}},f:function(a,b){try{return a=B(a),Lc(b,ac(a))}catch(d){if(typeof Y=="undefined"||d.name!=="ErrnoError")throw d;return-d.Ra}},o:function(a,b,d){try{b=B(b);b=Kc(a,b);if(d)if(d===512)$b(b);else return-28;else qa(b);return 0}catch(c){if(typeof Y==
"undefined"||c.name!=="ErrnoError")throw c;return-c.Ra}},n:function(a,b,d,c){try{c&=256;b=B(b);b=Kc(a,b,!0);var e=Date.now();if(d){function r(v){var l=I[v+8>>2];return l==1073741823?e:l==1073741822?null:(J[v>>2]+I[v+4>>2]*4294967296+(l/1E4|0)*1E4/1E9)*1E3}var g=r(d);var n=r(d+16)}else n=g=e;(n??g)!==null&&ec(b,g,n,c);return 0}catch(r){if(typeof Y=="undefined"||r.name!=="ErrnoError")throw r;return-r.Ra}},w:()=>Pa(""),v:()=>{Xa=!1;Oc=0},A:function(a,b){a=a<-9007199254740992||a>9007199254740992?NaN:
Number(a);a=new Date(a*1E3);if(isNaN(a.getTime()))return 1;I[b>>2]=a.getSeconds();I[b+4>>2]=a.getMinutes();I[b+8>>2]=a.getHours();I[b+12>>2]=a.getDate();I[b+16>>2]=a.getMonth();I[b+20>>2]=a.getFullYear()-1900;I[b+24>>2]=a.getDay();var d=a.getFullYear();I[b+28>>2]=(d%4!==0||d%100===0&&d%400!==0?Qc:Pc)[a.getMonth()]+a.getDate()-1|0;I[b+36>>2]=-(a.getTimezoneOffset()*60);d=(new Date(a.getFullYear(),6,1)).getTimezoneOffset();var c=(new Date(a.getFullYear(),0,1)).getTimezoneOffset();I[b+32>>2]=(d!=c&&
a.getTimezoneOffset()==Math.min(c,d))|0;return 0},y:function(a,b,d,c,e,g,n){e=e<-9007199254740992||e>9007199254740992?NaN:Number(e);try{var r=V(c);if(b&2&&!(d&2)&&(r.flags&2097155)!==2)throw new O(2);if((r.flags&2097155)===1)throw new O(2);if(!r.Pa.mb)throw new O(43);if(!a)throw new O(28);var v=r.Pa.mb(r,a,e,b,d);var l=v.ec;I[g>>2]=v.Lb;J[n>>2]=l;return 0}catch(z){if(typeof Y=="undefined"||z.name!=="ErrnoError")throw z;return-z.Ra}},z:function(a,b,d,c,e,g){g=g<-9007199254740992||g>9007199254740992?
NaN:Number(g);try{var n=V(e);if(d&2){if((n.node.mode&61440)!==32768)throw new O(43);c&2||n.Pa.nb&&n.Pa.nb(n,H.subarray(a,a+b),g,b,c)}}catch(r){if(typeof Y=="undefined"||r.name!=="ErrnoError")throw r;return-r.Ra}},k:(a,b)=>{Rc[a]&&(clearTimeout(Rc[a].id),delete Rc[a]);if(!b)return 0;var d=setTimeout(()=>{delete Rc[a];var c=[a,performance.now()],e=cd;if(!Ea)try{e(...c)}catch(g){g instanceof Va||g=="unwind"||ta(1,g)}finally{if(!(Xa||Oc>0))try{Fa=c=Fa,Sc(c)}catch(g){g instanceof Va||g=="unwind"||ta(1,
g)}}},b);Rc[a]={id:d,uc:b};return 0},B:(a,b,d,c)=>{var e=(new Date).getFullYear(),g=(new Date(e,0,1)).getTimezoneOffset();e=(new Date(e,6,1)).getTimezoneOffset();J[a>>2]=Math.max(g,e)*60;I[b>>2]=Number(g!=e);b=n=>{var r=Math.abs(n);return`UTC${n>=0?"-":"+"}${String(Math.floor(r/60)).padStart(2,"0")}${String(r%60).padStart(2,"0")}`};a=b(g);b=b(e);e<g?(M(a,H,d,17),M(b,H,c,17)):(M(a,H,c,17),M(b,H,d,17))},d:()=>Date.now(),p:()=>2147483648,c:()=>performance.now(),l:a=>{var b=H.length;a>>>=0;if(a>2147483648)return!1;
for(var d=1;d<=4;d*=2){var c=b*(1+.2/d);c=Math.min(c,a+100663296);a:{c=(Math.min(2147483648,Math.ceil(Math.max(a,c)/65536)*65536)-Ha.buffer.byteLength+65535)/65536|0;try{Ha.grow(c);Ga();var e=1;break a}catch(g){}e=void 0}if(e)return!0}return!1},F:(a,b)=>{var d=0,c=0,e;for(e of Vc()){var g=b+d;J[a+c>>2]=g;d+=M(e,H,g,Infinity)+1;c+=4}return 0},G:(a,b)=>{var d=Vc();J[a>>2]=d.length;a=0;for(var c of d)a+=m(c)+1;J[b>>2]=a;return 0},e:function(a){try{var b=V(a);hc(b);return 0}catch(d){if(typeof Y=="undefined"||
d.name!=="ErrnoError")throw d;return d.Ra}},m:function(a,b){try{var d=V(a);u[b]=d.tty?2:Q(d.mode)?3:(d.mode&61440)===40960?7:4;Ia[b+2>>1]=0;L[b+8>>3]=BigInt(0);L[b+16>>3]=BigInt(0);return 0}catch(c){if(typeof Y=="undefined"||c.name!=="ErrnoError")throw c;return c.Ra}},t:function(a,b,d,c){try{a:{var e=V(a);a=b;for(var g,n=b=0;n<d;n++){var r=J[a>>2],v=J[a+4>>2];a+=8;try{var l=e,z=r,F=v,ba=g,za=u;if(F<0||ba<0)throw new O(28);if(l.fd===null)throw new O(8);if((l.flags&2097155)===1)throw new O(8);if(Q(l.node.mode))throw new O(31);
if(!l.Pa.read)throw new O(28);var ma=typeof ba!="undefined";if(!ma)ba=l.position;else if(!l.seekable)throw new O(70);var Aa=l.Pa.read(l,za,z,F,ba);ma||(l.position+=Aa);var ha=Aa}catch(N){if(b>0&&N instanceof O&&(N.Ra==6||N.Ra==6))break;throw N;}if(ha<0){var Ba=-1;break a}b+=ha;if(ha<v)break;typeof g!="undefined"&&(g+=ha)}Ba=b}J[c>>2]=Ba;return 0}catch(N){if(typeof Y=="undefined"||N.name!=="ErrnoError")throw N;return N.Ra}},D:function(a,b,d,c){b=b<-9007199254740992||b>9007199254740992?NaN:Number(b);
try{if(isNaN(b))return 22;var e=V(a);ic(e,b,d);L[c>>3]=BigInt(e.position);e.ub&&!b&&d===0&&(e.ub=null);return 0}catch(g){if(typeof Y=="undefined"||g.name!=="ErrnoError")throw g;return g.Ra}},J:function(a){try{var b=V(a);return b.Pa?.fsync?.(b)}catch(d){if(typeof Y=="undefined"||d.name!=="ErrnoError")throw d;return d.Ra}},q:function(a,b,d,c){try{var e=V(a);a=b;if(d==1)var g=jc(e,u,J[a>>2],J[a+4>>2]);else{for(var n=b=0,r=a;n<d;n++,r+=8)b+=J[r+4>>2];var v=new Uint8Array(b);for(n=r=0;n<d;n++,a+=8){var l=
J[a>>2],z=J[a+4>>2];v.set(H.subarray(l,l+z),r);r+=z}g=jc(e,v,0,b)}J[c>>2]=g;return 0}catch(F){if(typeof Y=="undefined"||F.name!=="ErrnoError")throw F;return F.Ra}},u:Sc};async function ed(){La();var a=k.setStatus;a&&(a("Running..."),await new Promise(b=>setTimeout(b,1)),setTimeout(a,1,""));Ea||(k.noFSInit||Gb||Jc(),fd.O(),Hb=!1,k.onRuntimeInitialized?.(),Na())}var fd;
(async function(){function a(c){c=fd=c.exports;k._sqlite3_free=c.Q;k._sqlite3_value_text=c.R;k._sqlite3_prepare_v2=c.S;k._sqlite3_step=c.T;k._sqlite3_reset=c.U;k._sqlite3_exec=c.V;k._sqlite3_finalize=c.W;k._sqlite3_column_name=c.X;k._sqlite3_column_text=c.Y;k._sqlite3_column_type=c.Z;k._sqlite3_errmsg=c._;k._sqlite3_backup_init=c.$;k._sqlite3_backup_step=c.aa;k._sqlite3_backup_finish=c.ba;k._sqlite3_clear_bindings=c.ca;k._sqlite3_value_blob=c.da;k._sqlite3_value_bytes=c.ea;k._sqlite3_value_double=
c.fa;k._sqlite3_value_int=c.ga;k._sqlite3_value_type=c.ha;k._sqlite3_result_blob=c.ia;k._sqlite3_result_double=c.ja;k._sqlite3_result_error=c.ka;k._sqlite3_result_int=c.la;k._sqlite3_result_int64=c.ma;k._sqlite3_result_null=c.na;k._sqlite3_result_text=c.oa;k._sqlite3_aggregate_context=c.pa;k._sqlite3_column_count=c.qa;k._sqlite3_data_count=c.ra;k._sqlite3_column_blob=c.sa;k._sqlite3_column_bytes=c.ta;k._sqlite3_column_double=c.ua;k._sqlite3_bind_blob=c.va;k._sqlite3_bind_double=c.wa;k._sqlite3_bind_int=
c.xa;k._sqlite3_bind_text=c.ya;k._sqlite3_bind_parameter_index=c.za;k._sqlite3_sql=c.Aa;k._sqlite3_normalized_sql=c.Ba;k._sqlite3_changes=c.Ca;k._sqlite3_close_v2=c.Da;k._sqlite3_create_function_v2=c.Ea;k._sqlite3_update_hook=c.Fa;k._sqlite3_open=c.Ga;ea=k._malloc=c.Ha;y=k._free=c.Ia;k._RegisterExtensionFunctions=c.Ja;sb=c.Ka;cd=c.La;pa=c.Ma;la=c.Na;na=c.Oa;Ha=c.N;Z=c.P;Ga();return fd}var b={a:dd},d=k.instantiateWasm;if(d)return new Promise(c=>{d(b,e=>c(a(e)))});Qa??=k.locateFile?k.locateFile("sql-wasm.wasm",
va):va+"sql-wasm.wasm";return function(c){return a(c.instance)}(await Ta(b))})().then(()=>ed());


        // The shell-pre.js and emcc-generated code goes above
        return Module;
    }); // The end of the promise being returned

  return initSqlJsPromise;
} // The end of our initSqlJs function

// This bit below is copied almost exactly from what you get when you use the MODULARIZE=1 flag with emcc
// However, we don't want to use the emcc modularization. See shell-pre.js
if (typeof exports === 'object' && typeof module === 'object'){
    module.exports = initSqlJs;
    // This will allow the module to be used in ES6 or CommonJS
    module.exports.default = initSqlJs;
}
else if (typeof define === 'function' && define['amd']) {
    define([], function() { return initSqlJs; });
}
else if (typeof exports === 'object'){
    exports["Module"] = initSqlJs;
}
/* global initSqlJs */
/* eslint no-restricted-globals: ["error"] */

"use strict";

var db;

function onModuleReady(SQL) {
    function createDb(data) {
        if (db != null) db.close();
        db = new SQL.Database(data);
        return db;
    }

    var buff; var data; var result;
    data = this["data"];
    var config = data["config"] ? data["config"] : {};
    switch (data && data["action"]) {
        case "open":
            buff = data["buffer"];
            createDb(buff && new Uint8Array(buff));
            return postMessage({
                id: data["id"],
                ready: true
            });
        case "exec":
            if (db === null) {
                createDb();
            }
            if (!data["sql"]) {
                throw "exec: Missing query string";
            }
            return postMessage({
                id: data["id"],
                results: db.exec(data["sql"], data["params"], config)
            });
        case "getRowsModified":
            return postMessage({
                id: data["id"],
                rowsModified: db.getRowsModified()
            });
        case "each":
            if (db === null) {
                createDb();
            }
            var callback = function callback(row) {
                return postMessage({
                    id: data["id"],
                    row: row,
                    finished: false
                });
            };
            var done = function done() {
                return postMessage({
                    id: data["id"],
                    finished: true
                });
            };
            return db.each(data["sql"], data["params"], callback, done, config);
        case "export":
            buff = db["export"]();
            result = {
                id: data["id"],
                buffer: buff
            };
            try {
                return postMessage(result, [result]);
            } catch (error) {
                return postMessage(result);
            }
        case "close":
            if (db) {
                db.close();
                db = null;
            }
            return postMessage({
                id: data["id"]
            });
        default:
            throw new Error("Invalid action : " + (data && data["action"]));
    }
}

function onError(err) {
    return postMessage({
        id: this["data"]["id"],
        error: err["message"]
    });
}

db = null;
var sqlModuleReady = initSqlJs();

function global_sqljs_message_handler(event) {
    return sqlModuleReady
        .then(onModuleReady.bind(event))
        .catch(onError.bind(event));
}

if (typeof importScripts === "function") {
    self.onmessage = global_sqljs_message_handler;
}

if (typeof require === "function") {
    var worker_threads = require("worker_threads");
    var parentPort = worker_threads.parentPort;
    // eslint-disable-next-line no-undef
    globalThis.postMessage = parentPort.postMessage.bind(parentPort);
    parentPort.on("message", function onmessage(data) {
        var event = { data: data };
        global_sqljs_message_handler(event);
    });

    if (typeof process !== "undefined") {
        process.on("uncaughtException", function uncaughtException(err) {
            postMessage({ error: err.message });
        });
        process.on("unhandledRejection", function unhandledRejection(err) {
            postMessage({ error: err.message });
        });
    }
}
