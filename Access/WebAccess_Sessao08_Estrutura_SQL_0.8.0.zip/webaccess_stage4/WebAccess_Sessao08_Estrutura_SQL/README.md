# WebAccess — Sessão 08 (Gerenciamento da Estrutura e Editor SQL)

## O que esta versão acrescenta
Esta versão dá continuidade à Sessão 06 e implementa o editor SQL utilizando o SQL.js 1.14.1 já incorporado localmente. Não há dependência de CDN ou conexão com a internet para executar o aplicativo.

O editor permite executar uma instrução SQL por vez:
- `SELECT` — consulta e apresenta os resultados em uma grade.
- `INSERT` — insere registros.
- `UPDATE` — atualiza registros.
- `DELETE` — exclui registros.

O atalho **Ctrl+Enter** executa o comando. A interface informa erros do SQLite e, nos comandos de alteração, mostra a quantidade de registros afetados.

## Persistência das alterações
Quando um comando `INSERT`, `UPDATE` ou `DELETE` é executado:
1. O comando é executado pelo SQLite.
2. Os registros das tabelas são sincronizados de volta para a estrutura de dados do WebAccess.
3. O snapshot JSON é salvo no object store original `bancos`, chave `banco_atual`.
4. A cópia binária SQLite é atualizada no object store `sqlite_bancos`, chave `banco_sqlite`.

Assim, as alterações SQL permanecem disponíveis ao reabrir o WebAccess e continuam incluídas no backup JSON.

## Etapa 4 — gerenciamento da estrutura
Além dos comandos de dados, esta versão aceita comandos de estrutura:
- `CREATE TABLE` — cria uma tabela e seus campos.
- `ALTER TABLE` — altera a estrutura conforme os recursos suportados pelo SQLite, por exemplo `ADD COLUMN` e `RENAME COLUMN`.
- `DROP TABLE` — exclui uma tabela.

Após cada comando DDL, o WebAccess consulta o catálogo do SQLite (`sqlite_master` e `PRAGMA table_info` / `PRAGMA foreign_key_list`) e atualiza sua estrutura visual, preservando os identificadores internos de tabelas e registros quando possível. Chaves primárias de uma única coluna e chaves estrangeiras de uma única coluna são representadas no modelo do WebAccess. Chaves primárias e estrangeiras compostas não são suportadas pelo modelo visual. Para evitar que a reconstrução do banco elimine propriedades que o modelo ainda não armazena, esta etapa também bloqueia `NOT NULL`, `UNIQUE`, `CHECK`, `DEFAULT`, `COLLATE` e `AUTOINCREMENT` em comandos DDL.

A tela **Tabelas** continua permitindo criar e editar campos e definir a PK. A tela **Relacionamentos** permite definir a ligação 1:N e o modelo é convertido em restrições FOREIGN KEY reais no SQLite. A integridade referencial continua sendo aplicada pelo mecanismo SQLite.

## Limites desta etapa
- Execute uma instrução por vez.
- São aceitos `SELECT`, `INSERT`, `UPDATE`, `DELETE`, `CREATE TABLE`, `ALTER TABLE` e `DROP TABLE` (somente operações sobre tabelas; não são habilitados CREATE INDEX, VIEW ou TRIGGER).
- Os comandos de estrutura agora estão disponíveis nesta versão.
- Faça um backup JSON antes de alterações importantes, especialmente antes de usar `UPDATE` ou `DELETE` sem uma cláusula `WHERE`.
- A execução SQL respeita as chaves estrangeiras configuradas no banco SQLite.

## Atualização
1. Faça um backup JSON pelo WebAccess atual.
2. Feche as outras abas do WebAccess.
3. Extraia esta versão em uma pasta nova para teste ou sobre a pasta do aplicativo, sem apagar a pasta de dados do navegador.
4. Abra `index.html` no mesmo navegador e perfil usados anteriormente.
5. Aguarde os indicadores de armazenamento e SQLite ficarem prontos.
6. Abra **Consultas SQL** e teste primeiro um `SELECT`.

**Importante:** não limpe os dados do site, não exclua o IndexedDB e não remova a versão anterior até confirmar que a nova versão está funcionando.

## Arquivos principais
- `index.html`: interface do aplicativo e editor SQL.
- `css/style.css`: estilos da interface e do editor.
- `js/app.js`: eventos do editor e sincronização com o modelo WebAccess.
- `js/sqlite.js`: execução SQL e integração com SQL.js.
- `js/persistencia.js`: armazenamento JSON e cópia SQLite no IndexedDB.
- `lib/sql-wasm-inline.js`: SQL.js 1.14.1 com WebAssembly incorporado.
